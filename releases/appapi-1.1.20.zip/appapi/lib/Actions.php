<?php
namespace AppApi;

/**
 * 글 아래 기능: 추천·비추천(취소), 추천인 목록, 스크랩, 신고.
 *
 * 쓸 수 있는지는 게시판(문서 모듈) 설정을 따르고(추천: 사용 Y / 사용·추천인 공개 S / 사용 안 함 N),
 * 실제 처리는 웹과 같은 엔진 함수로 한다. 엔진의 추천·추천인 목록 함수는 글을 읽을 권한을 보지 않으므로
 * 여기서 먼저 읽을 수 있는 글인지 확인한다.
 */
class Actions
{
	/** 글 보기 응답에 넣는 기능 상태 */
	public static function forDocument($oDocument)
	{
		$config = self::config($oDocument);
		$logged_info = \Context::get('logged_info');
		$member_srl = $logged_info && $logged_info->member_srl ? (int)$logged_info->member_srl : 0;
		$is_rhymix = Core::$engine === 'rhymix';
		// 추천인 표시 애드온이 이 게시판에서 돌면 웹 글 아래에 추천인이 늘 보이므로 앱도 공개로 다룬다
		$addon = self::voterAddonRuns((int)$oDocument->get('module_srl'));
		$module_srl = (int)$oDocument->get('module_srl');
		// 단추는 웹이 이 사람에게 보이는 그대로 (1.1.20~): 엔진이 그린 이 글의 스킨 화면에 그 단추가 있거나,
		// 엔진의 '이 게시물을…' 메뉴가 있으면 엔진처럼 회원이 남의 글을 볼 때만 (메뉴의 추천·비추천·신고는 엔진이 그 조건으로 넣는다)
		$own = $member_srl && abs((int)$oDocument->get('member_srl')) === $member_srl;
		$web = self::buttons('document', (int)$oDocument->document_srl, (int)$oDocument->document_srl, $module_srl);
		$menu_vote = $web['menu'] && $member_srl && !$own;
		$up = self::state(($web['up'] || $menu_vote) ? ($config->use_vote_up ?? 'Y') : 'N', (int)$oDocument->get('voted_count'));
		if ($addon && $up['enabled'])
		{
			$up['public'] = true;
		}
		$declare = ($web['rendered'] || self::skinShows($oDocument, 'report')) && (($web['declare'] && ($member_srl || $web['rendered'])) || ($web['menu'] && $member_srl));
		$declared = $member_srl && method_exists($oDocument, 'getDeclared') && $oDocument->getDeclared();
		return array(
			'vote_up' => $up,
			'vote_down' => self::state(($web['down'] || $menu_vote) ? ($config->use_vote_down ?? 'Y') : 'N', abs((int)$oDocument->get('blamed_count'))),
			// 1 = 추천함, -1 = 비추천함, 0 = 안 함
			'my_vote' => $member_srl ? self::myVote((int)$oDocument->document_srl, $member_srl) : 0,
			// 추천 취소는 Rhymix 에서 게시판이 허용할 때만 (XE 에는 취소 기능이 없다)
			'can_cancel_vote' => $is_rhymix && ($config->allow_vote_cancel ?? 'N') === 'Y',
			'is_mine' => (bool)$own,
			// 웹이 글 화면에 추천·비추천 단추를 직접 그리면 자기 글에서도 누를 수 있게 보인다 (1.1.20~, 엔진이 거절하면 그 안내). 메뉴로만 되면 자기 글에는 메뉴에 없다
			'own_vote' => $web['up'] || $web['down'],
			// 스킨이 직접 그린 단추는 비회원에게 보이면 앱도 보인다(누르면 로그인), 엔진 메뉴로만 되면 회원에게만 (1.1.20~)
			'can_scrap' => ($web['rendered'] || self::skinShows($oDocument, 'scrap')) && (($web['scrap'] && ($member_srl || $web['rendered'])) || ($web['menu'] && $member_srl)),
			// 신고: 엔진 메뉴는 회원이면 자기 글에도 넣는다(웹과 같게). 이미 신고했으면 웹 메뉴는 '신고 취소' → 앱은 '신고됨'(declared)
			'can_declare' => $declare && !$declared,
			'declared' => $declare && $declared,
			// 이미 내 스크랩에 있는지 (0.10.12~): 앱은 책갈피를 채워 보이고, 다시 누르면 스크랩에서 뺀다
			'scrapped' => $member_srl ? self::isScrapped((int)$oDocument->document_srl, $member_srl) : false,
		);
	}

	/** 이 요청에서 엔진이 그린 게시판 스킨 화면. 글 번호 => array(이 사람의 화면, 비회원이면 회원 기준 화면) */
	private static $web = array();

	/**
	 * 글 보기·댓글 쪽 요청에서 엔진이 웹 글 보기(dispBoardContent)를 실행한 뒤 부른다 (1.1.20~): 그 결과로 게시판 스킨 화면(레이아웃 빼고)을
	 * 웹과 똑같이 그려 두고, 추천·비추천·스크랩·신고 단추는 이 화면에 있는 것만 앱에 낸다. 스킨 설정·회원 여부·글쓴이 여부가 모두 반영된다.
	 * 비회원이면 회원 기준 화면도 그린다: 비회원에게도 단추는 보이고 누르면 로그인을 묻는 스킨(단추의 onclick 만 `|cond="$is_logged"`)을 알아보려고.
	 */
	public static function captureWeb($oModule, $oDocument)
	{
		$srl = $oDocument ? (int)$oDocument->document_srl : 0;
		if (!$srl || array_key_exists($srl, self::$web))
		{
			return;
		}
		// 회원 기준 화면은 비회원 화면에 단추가 없을 때만 그린다 (memberSkin)
		self::$web[$srl] = array('html' => self::renderSkin($oModule, false), 'member' => false, 'module' => $oModule);
	}

	/** 비회원이면 회원 기준 화면 (처음 물을 때 한 번 그린다), 회원이면 null */
	private static function memberSkin($document_srl)
	{
		$web =& self::$web[$document_srl];
		if ($web['member'] === false)
		{
			$web['member'] = ($web['html'] !== null && !\Context::get('is_logged')) ? self::renderSkin($web['module'], true) : null;
		}
		return $web['member'];
	}

	/** 엔진의 템플릿 처리기로 모듈이 정한 스킨 화면을 그린다. 실패하면 null (그때는 스킨 파일 글자로 판단) */
	private static function renderSkin($oModule, $as_member)
	{
		if (!$oModule || !method_exists($oModule, 'getTemplatePath') || !class_exists('TemplateHandler'))
		{
			return null;
		}
		$path = (string)$oModule->getTemplatePath();
		$file = (string)$oModule->getTemplateFile();
		if ($path === '' || $file === '')
		{
			return null;
		}
		$was_logged = \Context::get('is_logged');
		if ($as_member)
		{
			\Context::set('is_logged', true);
		}
		$level = ob_get_level();
		ob_start();
		try
		{
			$html = (string)\TemplateHandler::getInstance()->compile($path, $file);
		}
		catch (\Throwable $e)
		{
			$html = '';
		}
		while (ob_get_level() > $level)
		{
			ob_end_clean();
		}
		if ($as_member)
		{
			\Context::set('is_logged', $was_logged);
		}
		return $html !== '' ? $html : null;
	}

	/**
	 * 웹이 이 글(kind=document)·댓글(kind=comment)에 보이는 단추: up·down·scrap·declare 는 스킨이 직접 그린 단추, menu 는 엔진의 '이 게시물을…'·'이 댓글을…' 메뉴.
	 * 그린 화면이 없으면(추천·스크랩 처리 요청, 그리기 실패) 예전처럼 스킨 파일 글자로 (rendered = false).
	 */
	private static function buttons($kind, $srl, $document_srl, $module_srl)
	{
		$Kind = $kind === 'comment' ? 'Comment' : 'Document';
		$patterns = array(
			'up' => 'proc' . $Kind . 'VoteUp(?:Cancel)?',
			'down' => 'proc' . $Kind . 'VoteDown(?:Cancel)?',
			'scrap' => $kind === 'comment' ? null : 'procMemberScrapDocument',
			'declare' => $kind === 'comment' ? '(?:procCommentDeclare|dispCommentDeclare)' : '(?:procDocumentDeclare|dispDocumentDeclare)',
		);
		$html = isset(self::$web[$document_srl]) ? self::$web[$document_srl]['html'] : null;
		if ($html === null)
		{
			$feature = 'board_features->' . $kind . '->';
			return array(
				'rendered' => false,
				'up' => self::skinHas($module_srl, array('proc' . $Kind . 'VoteUp', $feature . 'vote')),
				'down' => self::skinHas($module_srl, array('proc' . $Kind . 'VoteDown', $feature . 'vote')),
				'menu' => self::skinHas($module_srl, array('class="' . $kind . '_{')),
				'scrap' => $kind !== 'comment' && self::skinHas($module_srl, array('procMemberScrapDocument')),
				'declare' => self::skinHas($module_srl, $kind === 'comment' ? array('procCommentDeclare', 'dispCommentDeclare', $feature . 'report') : array('procDocumentDeclare', 'dispDocumentDeclare', $feature . 'report')),
			);
		}
		$result = array('rendered' => true);
		foreach ($patterns as $key => $action)
		{
			if ($action === null)
			{
				$result[$key] = false;
				continue;
			}
			// 단추 하나(태그 하나) 안에 동작 이름과 이 글·댓글 번호가 함께 있는 것
			$mine = self::tagsWith($html, $action, $srl);
			$result[$key] = !empty($mine) || (($member = self::memberSkin($document_srl)) !== null && self::guestSees(self::tagsWith($member, $action, $srl), $html));
		}
		// 엔진 메뉴 링크: class 에 document_<번호>·comment_<번호> (본문 감싸개 document_<번호>_<회원번호> 는 아님)
		$result['menu'] = (bool)preg_match('/class\s*=\s*["\'][^"\']*\b' . $kind . '_' . (int)$srl . '\b(?!_)/i', $html);
		return $result;
	}

	/** 화면에서 동작 이름(정규식 조각)과 이 번호가 함께 든 태그들 */
	private static function tagsWith($html, $action, $srl)
	{
		if (!preg_match_all('/<[a-z][^<>]*\b' . $action . '\b[^<>]*>/i', $html, $m))
		{
			return array();
		}
		return array_values(array_filter($m[0], function ($tag) use ($srl) {
			return (bool)preg_match('/(?<![0-9])' . (int)$srl . '(?![0-9])/', $tag);
		}));
	}

	/** 회원 화면의 그 단추(태그)가 onclick·href 만 빠진 꼴로 비회원 화면에도 있는가: 단추는 보이고 누르면 로그인을 묻는 스킨 */
	private static function guestSees(array $member_tags, $guest)
	{
		if (!$member_tags)
		{
			return false;
		}
		$normalize = function ($tag) {
			$tag = preg_replace('/\s+(?:onclick|href)\s*=\s*(?:"[^"]*"|\'[^\']*\')/i', '', $tag);
			return trim(preg_replace('/\s+/', ' ', $tag));
		};
		preg_match_all('/<(?:a|button)\b[^<>]*>/i', $guest, $g);
		$seen = array_flip(array_map($normalize, $g[0]));
		foreach ($member_tags as $tag)
		{
			if (isset($seen[$normalize($tag)]))
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * 게시판의 웹 스킨(PC 스킨 폴더의 html·js)이 이 단추를 그리는가: 엔진 동작 이름(procDocumentVoteUp 등), Rhymix 스킨의 board_features,
	 * 또는 엔진이 추천·스크랩·신고를 넣어 주는 '이 게시물을…'·'이 댓글을…' 메뉴(class="document_{…}"·class="comment_{…}") 중 하나라도 있으면 그린다.
	 * 스킨 폴더를 찾지 못하면 그린다고 본다(엔진 설정만 따른다)
	 */
	public static function skinHas($module_srl, array $needles)
	{
		static $texts = array();
		$module_info = getModel('module')->getModuleInfoByModuleSrl((int)$module_srl);
		$skin = $module_info ? preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)($module_info->skin ?? '')) : '';
		if ($skin === '')
		{
			$skin = 'default';
		}
		if (!isset($texts[$skin]))
		{
			$dir = \_XE_PATH_ . 'modules/board/skins/' . $skin;
			$text = null;
			if (is_dir($dir))
			{
				$text = '';
				$it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
				foreach ($it as $file)
				{
					if (preg_match('/\.(html|js)$/', $file->getFilename()) && $file->getSize() < 2000000)
					{
						$text .= (string)@file_get_contents($file->getPathname()) . "\n";
					}
				}
			}
			$texts[$skin] = $text;
		}
		if ($texts[$skin] === null)
		{
			return true;
		}
		foreach ($needles as $needle)
		{
			if (strpos($texts[$skin], $needle) !== false)
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * 게시판 스킨이 글 아래 신고(report)·스크랩(scrap) 버튼을 보이는지. 웹에서 안 보이는 버튼은 앱에도 두지 않는다.
	 * 엔진은 늘 허용하고 보일지는 스킨이 정하므로, 설정을 아는 스킨만 따로 본다. 그 밖의 스킨은 보인다.
	 * - lune_board: 스킨 설정 xv_d_report (n 둘 다 숨김 / r 신고만 / s 스크랩만). 사이트가 header.html 에서
	 *   `$lb->dm->report = false;` 처럼 값을 직접 정해 두었으면(kgpa) 그 값을 따른다.
	 */
	private static function skinShows($oDocument, $button)
	{
		static $cache = array();
		$module_info = getModel('module')->getModuleInfoByModuleSrl((int)$oDocument->get('module_srl'));
		if (!$module_info || ($module_info->skin ?? '') !== 'lune_board')
		{
			return true;
		}
		$key = $module_info->module_srl . '|' . $button;
		if (isset($cache[$key]))
		{
			return $cache[$key];
		}
		$option = (string)($module_info->xv_d_report ?? '');
		$shown = $button === 'report' ? !in_array($option, array('n', 's'), true) : !in_array($option, array('n', 'r'), true);
		$header = @file_get_contents(\_XE_PATH_ . 'modules/board/skins/lune_board/header.html');
		if ($header !== false && preg_match('/\$lb->dm->' . $button . '\s*=\s*([^;]*);/', $header, $m))
		{
			$value = strtolower(trim($m[1]));
			if ($value === 'false')
			{
				$shown = false;
			}
			elseif ($value === 'true')
			{
				$shown = true;
			}
		}
		return $cache[$key] = $shown;
	}

	/** 추천(point=1) · 비추천(point=-1). cancel=1 이면 취소 */
	public static function vote()
	{
		$oDocument = self::readableDocument();
		$point = (int)Core::param('point') === -1 ? -1 : 1;
		$cancel = (bool)Core::param('cancel');
		// 웹에 그 단추가 없는 게시판이면 앱에서도 받지 않는다 (forDocument 와 같은 판단)
		$state = self::forDocument($oDocument);
		if (empty($state[$point === 1 ? 'vote_up' : 'vote_down']['enabled']))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$act = ($point === 1 ? 'procDocumentVoteUp' : 'procDocumentVoteDown') . ($cancel ? 'Cancel' : '');
		if ($cancel && Core::$engine !== 'rhymix')
		{
			throw new ApiError(400, 'not_supported', Auth::lang('msg_invalid_request'));
		}
		self::run($act, array('module' => 'document', 'target_srl' => $oDocument->document_srl));
		// 엔진이 글 정보를 캐시해 두므로 추천 수는 DB 에서 다시 읽는다
		$result = self::forDocument($oDocument);
		$stmt = Core::pdo()->prepare('SELECT voted_count, blamed_count FROM `' . Core::tablePrefix() . 'documents` WHERE document_srl = ?');
		$stmt->execute(array((int)$oDocument->document_srl));
		if ($row = $stmt->fetch())
		{
			$result['vote_up']['count'] = (int)$row['voted_count'];
			$result['vote_down']['count'] = abs((int)$row['blamed_count']);
		}
		return $result;
	}

	/**
	 * 댓글 추천 상태 (모듈 1.0.18~, 기능 comment_vote). 댓글 모듈 설정(게시판별)이 추천·비추천을 모두 끄면 null.
	 * 비회원 추천은 엔진이 설정(allow_vote_non_member, 예전 non_login_vote)대로 받거나 거절한다
	 */
	public static function forComment($oComment)
	{
		static $configs = array();
		$module_srl = (int)$oComment->get('module_srl');
		if (!isset($configs[$module_srl]))
		{
			$config = getModel('module')->getModulePartConfig('comment', $module_srl);
			$configs[$module_srl] = is_object($config) ? $config : new \stdClass;
		}
		$config = $configs[$module_srl];
		$logged_info = \Context::get('logged_info');
		$member_srl = $logged_info && $logged_info->member_srl ? (int)$logged_info->member_srl : 0;
		// 웹이 이 사람에게 이 댓글에 보이는 단추 그대로 (1.1.20~, 글과 같은 판단): 스킨 화면의 단추, 또는 '이 댓글을…' 메뉴면 회원이 남의 댓글을 볼 때만
		$web = self::buttons('comment', (int)$oComment->comment_srl, (int)$oComment->get('document_srl'), $module_srl);
		$menu_vote = $web['menu'] && $member_srl && abs((int)$oComment->get('member_srl')) !== $member_srl;
		$up = ($web['up'] || $menu_vote) && ($config->use_vote_up ?? 'Y') !== 'N';
		$down = ($web['down'] || $menu_vote) && ($config->use_vote_down ?? 'Y') !== 'N';
		if (!$up && !$down)
		{
			return null;
		}
		return array(
			'up' => array('enabled' => $up, 'count' => (int)$oComment->get('voted_count')),
			'down' => array('enabled' => $down, 'count' => abs((int)$oComment->get('blamed_count'))),
			'my_vote' => $member_srl ? self::myCommentVote((int)$oComment->comment_srl, $member_srl) : 0,
			// 취소는 Rhymix 에서 설정이 허용할 때만 (XE 에는 취소 기능이 없다). 예전 설정은 게시판의 cancel_vote (Rhymix Features 와 같다)
			'can_cancel' => Core::$engine === 'rhymix' && (isset($config->allow_vote_cancel)
				? $config->allow_vote_cancel === 'Y'
				: (($m = getModel('module')->getModuleInfoByModuleSrl($module_srl)) && ($m->cancel_vote ?? 'N') === 'Y')),
		);
	}

	/**
	 * 댓글 신고 단추 (1.1.20~): 웹이 이 사람에게 이 댓글에 보이는 그대로 — 스킨이 직접 그린 신고 단추(비회원에게 보이면 누르면 로그인),
	 * 또는 엔진의 '이 댓글을…' 메뉴(회원이면 자기 댓글에도 신고를 넣는다). 이미 신고했으면 declared
	 */
	public static function commentDeclare($oComment)
	{
		$logged_info = \Context::get('logged_info');
		$member_srl = $logged_info && $logged_info->member_srl ? (int)$logged_info->member_srl : 0;
		$web = self::buttons('comment', (int)$oComment->comment_srl, (int)$oComment->get('document_srl'), (int)$oComment->get('module_srl'));
		$can = ($web['declare'] && ($member_srl || $web['rendered'])) || ($web['menu'] && $member_srl);
		$declared = $member_srl && method_exists($oComment, 'getDeclared') && $oComment->getDeclared();
		return array('can_declare' => $can && !$declared, 'declared' => $can && $declared);
	}

	/** 댓글 신고 (1.1.20~): 웹 '이 댓글을…' 메뉴·신고 단추와 같은 엔진 동작(procCommentDeclare) */
	public static function commentReport()
	{
		$comment_srl = Core::intParam('comment_srl');
		$oComment = $comment_srl ? getModel('comment')->getComment($comment_srl) : null;
		if (!$oComment || !$oComment->isExists())
		{
			throw new ApiError(404, 'comment_not_found', Auth::lang('msg_not_founded'));
		}
		self::readableDocument((int)$oComment->get('document_srl'));
		if ($oComment->isSecret() && !$oComment->isAccessible() && !$oComment->isGranted())
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		if (empty(self::commentDeclare($oComment)['can_declare']))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$reason = mb_substr(trim(Core::str('reason')), 0, 500);
		self::run('procCommentDeclare', array(
			'module' => 'comment', 'target_srl' => $comment_srl,
			'message_option' => $reason !== '' ? 'others' : null, 'declare_message' => $reason !== '' ? $reason : null,
		));
		return array('declared' => true);
	}

	/** 댓글 추천(point=1)·비추천(point=-1), cancel=1 이면 취소. 웹 댓글 단추와 같은 엔진 동작(procCommentVoteUp·Down) */
	public static function commentVote()
	{
		$comment_srl = Core::intParam('comment_srl');
		$oComment = $comment_srl ? getModel('comment')->getComment($comment_srl) : null;
		if (!$oComment || !$oComment->isExists())
		{
			throw new ApiError(404, 'comment_not_found', Auth::lang('msg_not_founded'));
		}
		// 엔진은 댓글이 보이는지만 보므로 글을 읽을 수 있는지 먼저 확인한다 (게시판·비밀글·상담 게시판)
		self::readableDocument((int)$oComment->get('document_srl'));
		if ($oComment->isSecret() && !$oComment->isAccessible() && !$oComment->isGranted())
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		if (!self::forComment($oComment))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$point = (int)Core::param('point') === -1 ? -1 : 1;
		$cancel = (bool)Core::param('cancel');
		if ($cancel && Core::$engine !== 'rhymix')
		{
			throw new ApiError(400, 'not_supported', Auth::lang('msg_invalid_request'));
		}
		$act = ($point === 1 ? 'procCommentVoteUp' : 'procCommentVoteDown') . ($cancel ? 'Cancel' : '');
		try
		{
			Board::run('', $act, array('module' => 'comment', 'target_srl' => $comment_srl), false);
		}
		catch (ApiError $e)
		{
			if ($e->status === 401)
			{
				throw $e;
			}
			// 이미 추천함, 자기 댓글 등 엔진이 거절한 이유를 그대로 보여 준다
			throw new ApiError(400, 'vote_failed', $e->getMessage());
		}
		// 엔진이 댓글 정보를 캐시해 두므로 추천 수는 DB 에서 다시 읽는다
		$vote = self::forComment($oComment);
		$stmt = Core::pdo()->prepare('SELECT voted_count, blamed_count FROM `' . Core::tablePrefix() . 'comments` WHERE comment_srl = ?');
		$stmt->execute(array($comment_srl));
		if ($row = $stmt->fetch())
		{
			$vote['up']['count'] = (int)$row['voted_count'];
			$vote['down']['count'] = abs((int)$row['blamed_count']);
		}
		return array('comment_srl' => $comment_srl, 'vote' => $vote);
	}

	private static function myCommentVote($comment_srl, $member_srl)
	{
		try
		{
			$stmt = Core::pdo()->prepare('SELECT point FROM `' . Core::tablePrefix() . 'comment_voted_log` WHERE comment_srl = ? AND member_srl = ? ORDER BY regdate DESC LIMIT 1');
			$stmt->execute(array($comment_srl, $member_srl));
			$point = (int)$stmt->fetchColumn();
			return $point > 0 ? 1 : ($point < 0 ? -1 : 0);
		}
		catch (\PDOException $e)
		{
			return 0;
		}
	}

	/** 추천인 목록: 게시판이 '추천인 공개'로 설정했을 때만 */
	public static function voters()
	{
		$oDocument = self::readableDocument();
		$point = (int)Core::param('point') === -1 ? -1 : 1;
		$config = self::config($oDocument);
		$setting = $point === 1 ? ($config->use_vote_up ?? 'Y') : ($config->use_vote_down ?? 'Y');
		$addon = $point === 1 && $setting !== 'N' && self::voterAddonRuns((int)$oDocument->get('module_srl'));
		if ($setting !== 'S' && !$addon)
		{
			throw new ApiError(403, 'not_public', Auth::lang('msg_not_permitted'));
		}
		$args = new \stdClass;
		$args->document_srl = (int)$oDocument->document_srl;
		if ($point === 1)
		{
			$args->more_point = 0;
		}
		else
		{
			$args->below_point = 0;
		}
		$output = executeQueryArray('document.getVotedMemberList', $args);
		$list = array();
		foreach ((array)$output->data as $row)
		{
			$image = getModel('member')->getProfileImage($row->member_srl);
			// 관리자 설정(이름 표시): 글이 속한 게시판의 값, 익명 게시판은 닉네임 그대로
			$name = Core::displayName(html_entity_decode((string)$row->nick_name, ENT_QUOTES, 'UTF-8'), (int)$row->member_srl, (int)$oDocument->get('module_srl'), 'voter');
			$list[] = array(
				'nick_name' => $name,
				'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			);
		}
		return array('voters' => $list);
	}

	/** 내 스크랩에 담기 */
	public static function scrap()
	{
		$oDocument = self::readableDocument();
		// 웹에 스크랩 단추가 없는 게시판이면 받지 않는다 (forDocument 와 같은 판단)
		if (!self::forDocument($oDocument)['can_scrap'])
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		try
		{
			self::run('procMemberScrapDocument', array('module' => 'member', 'document_srl' => $oDocument->document_srl));
		}
		catch (ApiError $e)
		{
			// 구 XE 는 스크랩에 성공해도 알림창용으로 오류 코드(-1)에 "등록했습니다"를 담아 돌려준다.
			// 실제로 스크랩됐으면 성공으로 본다 (이미 스크랩한 글 등 진짜 실패는 그대로 알린다)
			$args = new \stdClass;
			$args->document_srl = (int)$oDocument->document_srl;
			$args->member_srl = (int)\Context::get('logged_info')->member_srl;
			$output = executeQuery('member.getScrapDocument', $args);
			if (empty($output->data->count) || $e->getMessage() === Auth::lang('msg_alreay_scrapped'))
			{
				throw $e;
			}
		}
		return array('scrapped' => true);
	}

	/** 신고 */
	public static function report()
	{
		$oDocument = self::readableDocument();
		if (!self::forDocument($oDocument)['can_declare'])
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$reason = mb_substr(trim(Core::str('reason')), 0, 500);
		self::run('procDocumentDeclare', array(
			'module' => 'document', 'target_srl' => $oDocument->document_srl,
			'message_option' => $reason !== '' ? 'others' : null, 'declare_message' => $reason !== '' ? $reason : null,
		));
		return array('declared' => true);
	}

	// ---- 내부

	/** 이 게시판의 글이고 지금 회원이 읽을 수 있어야 한다 (비밀글·상담 게시판 포함, 설문 투표도 같은 확인) */
	public static function readableDocument($document_srl = null)
	{
		$mid = Core::str('mid');
		$module_info = preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid) ? getModel('module')->getModuleInfoByMid($mid) : null;
		if (!$module_info || $module_info->module !== 'board' || !Board::canReadBoard($module_info))
		{
			throw new ApiError(404, 'board_not_found', Auth::lang('msg_not_founded'));
		}
		$document_srl = $document_srl ?: Core::intParam('document_srl');
		$oDocument = $document_srl ? getModel('document')->getDocument($document_srl, false, false) : null;
		// 통합 게시판에서 연 글이면 그 글의 원래 게시판 기준으로 본다
		$module_info = ($oDocument && $oDocument->isExists()) ? Board::documentBoard($mid, $oDocument) : null;
		if (!$module_info)
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		$grant = Board::grant($module_info);
		$granted = $oDocument->isGranted();
		$readable = !empty($grant->view) || $granted;
		if ($readable && ($module_info->consultation ?? '') === 'Y' && !$granted)
		{
			$info = \Context::get('logged_info');
			$readable = $info && (int)$oDocument->get('member_srl') === (int)$info->member_srl;
		}
		if ($readable && $oDocument->isSecret() && !$granted && !$oDocument->isAccessible())
		{
			$readable = false;
		}
		if (!$readable)
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		return $oDocument;
	}

	/** 웹 글 아래에 추천인 목록을 붙이는 애드온 (사이트 운영자가 설치해 쓰는 것) */
	private static $voterAddons = array('colombo_add_vote_list', 'add_vote_list');

	/** 그 애드온이 켜져 있고 이 게시판에서 실행되는가 (엔진의 애드온 실행 규칙: 선택한 게시판 / 선택한 게시판 제외, 목록이 비면 전체) */
	private static function voterAddonRuns($module_srl)
	{
		static $rows = null;
		if ($rows === null)
		{
			$rows = array();
			$in = implode(',', array_fill(0, count(self::$voterAddons), '?'));
			foreach (array('addons_site', 'addons') as $table)
			{
				try
				{
					$where = $table === 'addons_site' ? ' AND site_srl = 0' : '';
					$stmt = Core::pdo()->prepare('SELECT addon, is_used, extra_vars FROM `' . Core::tablePrefix() . $table . "` WHERE addon IN ($in)" . $where);
					$stmt->execute(self::$voterAddons);
					foreach ($stmt->fetchAll() as $row)
					{
						if (!isset($rows[$row['addon']]))
						{
							$rows[$row['addon']] = $row;
						}
					}
				}
				catch (\PDOException $e)
				{
					// 표가 없는 엔진
				}
			}
		}
		$module_info = getModel('module')->getModuleInfoByModuleSrl($module_srl);
		$mid = $module_info ? $module_info->mid : '';
		foreach ($rows as $row)
		{
			if ($row['is_used'] !== 'Y' || !is_dir(\_XE_PATH_ . 'addons/' . $row['addon']))
			{
				continue;
			}
			$vars = @unserialize($row['extra_vars'], array('allowed_classes' => array('stdClass')));
			$mid_list = (is_object($vars) && !empty($vars->mid_list) && is_array($vars->mid_list)) ? $vars->mid_list : array();
			$method = is_object($vars) && !empty($vars->xe_run_method) ? $vars->xe_run_method : 'run_selected';
			$listed = in_array($mid, $mid_list, true);
			if ($method === 'no_run_selected' ? !$listed : ($listed || !$mid_list))
			{
				return true;
			}
		}
		return false;
	}

	private static function config($oDocument)
	{
		$config = getModel('module')->getModulePartConfig('document', (int)$oDocument->get('module_srl'));
		return is_object($config) ? $config : new \stdClass;
	}

	private static function state($setting, $count)
	{
		return array(
			'enabled' => $setting !== 'N',
			'count' => $count,
			// 'S' = 추천인 목록 공개
			'public' => $setting === 'S',
		);
	}

	/** 엔진의 스크랩 조회(member.getScrapDocument, 두 엔진 같은 이름)로 이미 스크랩했는지 */
	private static function isScrapped($document_srl, $member_srl)
	{
		$args = new \stdClass;
		$args->document_srl = $document_srl;
		$args->member_srl = $member_srl;
		$output = executeQuery('member.getScrapDocument', $args);
		return !empty($output->data->count);
	}

	private static function myVote($document_srl, $member_srl)
	{
		try
		{
			$stmt = Core::pdo()->prepare('SELECT point FROM `' . Core::tablePrefix() . 'document_voted_log` WHERE document_srl = ? AND member_srl = ? ORDER BY regdate DESC LIMIT 1');
			$stmt->execute(array($document_srl, $member_srl));
			$point = (int)$stmt->fetchColumn();
			return $point > 0 ? 1 : ($point < 0 ? -1 : 0);
		}
		catch (\PDOException $e)
		{
			return 0;
		}
	}

	private static function run($act, array $vars)
	{
		try
		{
			return Board::run('', $act, $vars, false);
		}
		catch (ApiError $e)
		{
			// 이미 추천함, 자기 글 등 엔진이 거절한 이유를 그대로 보여 준다
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
	}
}
