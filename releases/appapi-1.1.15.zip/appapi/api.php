<?php
/**
 * 게시판모아(BoardMoa) 앱 API 진입점.
 *
 * modules/appapi 모듈로 설치한다. 호출: /modules/appapi/api.php?r=<route> (예전 주소 /appapi/index.php 도 연결 파일로 지원)
 * 구 XE 1.x(PHP 7.1)와 Rhymix 2.x 모두에서 동작해야 하므로 PHP 7.1 문법만 쓴다.
 */

define('APPAPI_VERSION', '1.1.15');
define('APPAPI_DIR', __DIR__);

// 설치 위치(modules/appapi)에서만 돈다: 백업·복사본(files/appapi_backup 등)에 남은 이 파일이 웹에서 옛 API 로 실행되지 않게
if (!preg_match('#[/\\\\]modules[/\\\\]appapi$#', (string)realpath(__DIR__)))
{
	http_response_code(404);
	exit;
}

require APPAPI_DIR . '/lib/Text.php';
require APPAPI_DIR . '/lib/Names.php';
require APPAPI_DIR . '/lib/Response.php';
require APPAPI_DIR . '/lib/Core.php';
require APPAPI_DIR . '/lib/Tokens.php';
require APPAPI_DIR . '/lib/Views.php';
require APPAPI_DIR . '/lib/Auth.php';
require APPAPI_DIR . '/lib/Board.php';
require APPAPI_DIR . '/lib/Write.php';
require APPAPI_DIR . '/lib/Member.php';
require APPAPI_DIR . '/lib/Actions.php';
require APPAPI_DIR . '/lib/Polls.php';
require APPAPI_DIR . '/lib/Components.php';
require APPAPI_DIR . '/lib/ExtraVars.php';
require APPAPI_DIR . '/lib/People.php';
require APPAPI_DIR . '/lib/My.php';
require APPAPI_DIR . '/lib/Notify.php';
require APPAPI_DIR . '/lib/Menu.php';
require APPAPI_DIR . '/lib/Router.php';

AppApi\Router::run();
