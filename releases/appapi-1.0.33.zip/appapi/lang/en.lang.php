<?php
$lang->appapi = 'App API';
$lang->appapi_about = 'Settings used when the mobile board app connects to this site. Board permissions follow the site settings.';
