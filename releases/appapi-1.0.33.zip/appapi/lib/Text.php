<?php
/**
 * 모듈 문구 언어 (한국어 원문 + 앱과 같은 11개 언어). 한국어 원문을 열쇠로 appapiText::t('…') 에 넣고, 값 자리는 {0}, {1} …
 * 언어별 문구는 lang/text.<코드>.php (한국어 원문 → 그 언어, 열쇠는 text.en.php 와 같다).
 * - 관리 화면·업데이트: 관리 화면 언어
 * - 앱에 보내는 문구(오류 등): 앱이 보낸 언어(X-App-Lang: ko, en, ja, es, pt-BR, de, fr, it, vi, id, zh-Hant, zh-Hans), 없으면(예전 앱) 사이트 언어
 * - 없는 언어는 영어(한국어는 한국어일 때만). 문구 하나가 없으면 그 언어 → 기본 언어(pt-BR → pt) → 영어 → 한국어 원문
 * 엔진이 만든 문구와 사이트 내용(게시판 이름·글)은 바꾸지 않는다.
 * 앱(iOS·Android)의 tr() 과 같은 방식이다.
 */
class appapiText
{
	/** 문구 언어 (앱의 Lang.Code 와 같다). ko 는 원문이라 파일이 없다 */
	public static $languages = array('ko', 'en', 'ja', 'es', 'pt-BR', 'de', 'fr', 'it', 'vi', 'id', 'zh-Hant', 'zh-Hans');

	private static $code = null;
	private static $tables = array();

	public static function code()
	{
		if (self::$code === null)
		{
			$requested = isset($_SERVER['HTTP_X_APP_LANG']) ? trim((string)$_SERVER['HTTP_X_APP_LANG']) : '';
			if (defined('APPAPI_VERSION') && $requested !== '')
			{
				self::$code = self::resolve($requested);
			}
			else
			{
				$site = class_exists('Context') ? (string)Context::getLangType() : 'ko';
				self::$code = $site === '' ? 'ko' : self::resolve($site);
			}
		}
		return self::$code;
	}

	/**
	 * 언어 표시(앱 코드, 엔진 언어 jp·zh-TW, ko_KR 꼴 등) → 문구 언어. 없는 언어는 영어.
	 * 중국어는 번체(Hant·TW·HK·MO)는 zh-Hant, 그 밖(Hans·CN·SG·지역 없는 zh)은 zh-Hans, 포르투갈어는 모두 pt-BR.
	 */
	public static function resolve($tag)
	{
		$tag = strtolower(str_replace('_', '-', trim((string)$tag)));
		foreach (self::$languages as $code)
		{
			if (strtolower($code) === $tag)
			{
				return $code;
			}
		}
		$parts = explode('-', $tag);
		$base = $parts[0];
		if ($base === 'pt')
		{
			return 'pt-BR';
		}
		if ($base === 'jp')
		{
			return 'ja';
		}
		if ($base === 'in')
		{
			return 'id';
		}
		if ($base === 'zh')
		{
			$rest = array_slice($parts, 1);
			$traditional = in_array('hant', $rest, true) || (!in_array('hans', $rest, true) && array_intersect(array('tw', 'hk', 'mo'), $rest));
			return $traditional ? 'zh-Hant' : 'zh-Hans';
		}
		foreach (self::$languages as $code)
		{
			if ($code === $base)
			{
				return $code;
			}
		}
		return 'en';
	}

	/** lang/text.<코드>.php (없으면 빈 표) */
	private static function table($code)
	{
		if (!isset(self::$tables[$code]))
		{
			$file = dirname(__DIR__) . '/lang/text.' . $code . '.php';
			self::$tables[$code] = preg_match('/^[A-Za-z-]+$/', $code) && is_file($file) ? (array)include $file : array();
		}
		return self::$tables[$code];
	}

	public static function t($ko)
	{
		$text = $ko;
		$code = self::code();
		if ($code !== 'ko')
		{
			$base = explode('-', $code);
			foreach (array_unique(array($code, $base[0], 'en')) as $c)
			{
				$table = self::table($c);
				if (isset($table[$ko]))
				{
					$text = $table[$ko];
					break;
				}
			}
		}
		$args = func_get_args();
		for ($i = 1; $i < count($args); $i++)
		{
			$text = str_replace('{' . ($i - 1) . '}', (string)$args[$i], $text);
		}
		return $text;
	}
}

/** 관리 화면 템플릿용: {$tr->t('…')} */
class appapiTextView
{
	public function t($ko)
	{
		return call_user_func_array(array('appapiText', 't'), func_get_args());
	}
}
