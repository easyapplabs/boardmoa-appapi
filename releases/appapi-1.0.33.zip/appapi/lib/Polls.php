<?php
namespace AppApi;

/**
 * 글 속 설문(투표): 코어 poll 모듈 + 편집기 부품 poll_maker.
 *
 * 웹은 본문을 그릴 때 부품 자리(<img editor_component="poll_maker" poll_srl="…">)를 설문 스킨 HTML(폼·결과표)로 바꾼다.
 * 그 폼은 웹 세션·스크립트가 있어야 투표가 되므로, 앱이 with_polls=1 을 보내면 그 자리를 자리표시
 * <div data-bh-poll="번호"></div> 로 두고 설문 내용을 데이터(polls)로 준다. 앱은 그 자리에 설문 카드를 그린다.
 * with_polls 가 없으면(예전 앱) 본문은 지금까지와 똑같다.
 * 투표는 웹과 같은 엔진 동작(poll 모듈 procPoll)을 JSON 방식으로 실행한다.
 */
class Polls
{
	/** 편집기 부품을 찾는 식 (엔진 editorController::transComponent 와 같다) */
	const COMPONENT = '!<(?:(div)|img)([^>]*)editor_component=([^>]*)>(?(1)(.*?)</div>)!is';

	/**
	 * 부품을 바꾸기 전 본문에서 설문 부품을 자리표시로 바꾼다. 찾은 설문 번호(순서대로)를 $found 에 담는다.
	 * 지워진 설문은 그대로 둔다(엔진이 웹처럼 빈 것으로 바꾼다).
	 */
	public static function replaceComponents($content, &$found)
	{
		$found = array();
		if (stripos((string)$content, 'poll_maker') === false)
		{
			return $content;
		}
		return preg_replace_callback(self::COMPONENT, function ($m) use (&$found) {
			$srl = self::pollSrlOf($m);
			if (!$srl || !self::row($srl))
			{
				return $m[0];
			}
			$found[] = $srl;
			return '<div data-bh-poll="' . $srl . '"></div>';
		}, (string)$content);
	}

	/** 저장된 본문에 든 설문 번호들 (투표 요청이 그 글의 설문인지 확인) */
	public static function idsIn($content)
	{
		$ids = array();
		if (stripos((string)$content, 'poll_maker') !== false && preg_match_all(self::COMPONENT, (string)$content, $all, PREG_SET_ORDER))
		{
			foreach ($all as $m)
			{
				if ($srl = self::pollSrlOf($m))
				{
					$ids[] = $srl;
				}
			}
		}
		return $ids;
	}

	/** 부품의 속성 (엔진 transEditorComponent 와 같은 방식으로 읽는다) */
	private static function pollSrlOf($m)
	{
		$script = ' ' . $m[2] . ' editor_component=' . $m[3];
		$script = preg_replace('/([\w:-]+)\s*=(?:\s*(["\']))?((?(2).*?|[^ ]+))\2/i', '\1="\3"', $script);
		preg_match_all('/([a-z0-9_-]+)="([^"]+)"/is', $script, $mm);
		$attrs = array();
		foreach ($mm[1] as $i => $name)
		{
			$attrs[strtolower($name)] = $mm[2][$i];
		}
		if (($attrs['editor_component'] ?? '') !== 'poll_maker' || !ctype_digit((string)($attrs['poll_srl'] ?? '')))
		{
			return 0;
		}
		return (int)$attrs['poll_srl'];
	}

	private static function row($poll_srl)
	{
		static $cache = array();
		if (!array_key_exists($poll_srl, $cache))
		{
			$args = new \stdClass;
			$args->poll_srl = (int)$poll_srl;
			$output = executeQuery('poll.getPoll', $args);
			$cache[$poll_srl] = ($output && $output->toBool() && !empty($output->data)) ? $output->data : null;
		}
		return $cache[$poll_srl];
	}

	private static function plain($html)
	{
		return trim(html_entity_decode(strip_tags((string)$html), ENT_QUOTES, 'UTF-8'));
	}

	/**
	 * 설문 하나 (docs/API.md '글 속 설문').
	 * 마감·참여 판단은 엔진과 같다: stop_date 가 오늘보다 앞이면 끝남(그날까지 받는다), 참여는 poll 모델 isPolled(회원 번호 또는 IP).
	 * 결과는 웹 스킨의 [결과 보기]처럼 누구나 볼 수 있다.
	 */
	public static function info($poll_srl)
	{
		$args = new \stdClass;
		$args->poll_srl = (int)$poll_srl;
		$output = executeQuery('poll.getPoll', $args);
		$poll = ($output && $output->toBool() && !empty($output->data)) ? $output->data : null;
		if (!$poll)
		{
			return null;
		}
		$titles = executeQueryArray('poll.getPollTitle', $args);
		$items = executeQueryArray('poll.getPollItem', $args);

		$choices = array();
		foreach ((array)($items->data ?? array()) as $item)
		{
			$choices[(int)$item->poll_index_srl][] = array(
				'id' => (int)$item->poll_item_srl,
				'title' => self::plain($item->title),
				'count' => (int)$item->poll_count,
			);
		}
		$questions = array();
		foreach ((array)($titles->data ?? array()) as $title)
		{
			$list = $choices[(int)$title->poll_index_srl] ?? array();
			$checkcount = max(1, (int)$title->checkcount);
			$questions[] = array(
				'id' => (int)$title->poll_index_srl,
				'title' => self::plain($title->title),
				'checkcount' => $checkcount,
				// 웹 스킨 스크립트(doPoll)와 같은 규칙: 질문마다 1개 이상, checkcount 개 이하
				'min_choices' => 1,
				'max_choices' => max(1, min($checkcount, count($list))),
				'count' => (int)$title->poll_count,
				'choices' => $list,
			);
		}

		$stop = (string)$poll->stop_date;
		$ended = $stop < date('Ymd');
		$voted = (bool)getModel('poll')->isPolled((int)$poll_srl);
		return array(
			'id' => (int)$poll_srl,
			'title' => null,
			'questions' => $questions,
			'participants' => (int)$poll->poll_count,
			'end_date' => strlen($stop) >= 8 ? substr($stop, 0, 4) . '-' . substr($stop, 4, 2) . '-' . substr($stop, 6, 2) : null,
			'ended' => $ended,
			'voted' => $voted,
			'can_vote' => !$ended && !$voted && count($questions) > 0,
			// 비회원도 투표할 수 있다(엔진이 IP 로 한 번만 받는다)
			'login_required' => false,
			'result_visible' => true,
		);
	}

	/** 본문에서 찾은 설문들 */
	public static function infos(array $ids)
	{
		$polls = array();
		foreach (array_unique($ids) as $srl)
		{
			if ($info = self::info($srl))
			{
				$polls[] = $info;
			}
		}
		return $polls;
	}

	/**
	 * POST poll.vote {mid, document_srl, poll_id, choices: [선택지 번호…]} → {poll}
	 * 글을 읽을 수 있어야 하고, 그 글 본문에 든 설문이어야 한다.
	 */
	public static function vote()
	{
		$oDocument = Actions::readableDocument();
		$poll_srl = Core::intParam('poll_id');
		if (!$poll_srl || !in_array($poll_srl, self::idsIn($oDocument->get('content')), true))
		{
			throw new ApiError(404, 'poll_not_found', \appapiText::t('설문을 찾을 수 없습니다.'));
		}
		$info = self::info($poll_srl);
		if (!$info)
		{
			throw new ApiError(404, 'poll_not_found', \appapiText::t('설문을 찾을 수 없습니다.'));
		}
		\Context::loadLang(\ModuleHandler::getModulePath('poll') . 'lang');
		if ($info['ended'])
		{
			// XE 1.x 의 procPoll 은 마감을 보지 않는다(웹은 마감된 설문에 폼을 내지 않는다): 앞에서 막는다
			throw new ApiError(400, 'poll_ended', \appapiText::t('마감된 설문입니다.'));
		}

		// 선택: 이 설문의 선택지만, 질문마다 웹 스킨과 같은 개수 규칙
		$raw = Core::param('choices');
		if (!is_array($raw))
		{
			$raw = explode(',', (string)$raw);
		}
		$picked = array();
		foreach ($raw as $value)
		{
			if (ctype_digit(trim((string)$value)))
			{
				$picked[(int)$value] = true;
			}
		}
		$selected = array();
		foreach ($info['questions'] as $question)
		{
			$count = 0;
			foreach ($question['choices'] as $choice)
			{
				if (isset($picked[$choice['id']]))
				{
					$selected[] = $choice['id'];
					unset($picked[$choice['id']]);
					$count++;
				}
			}
			if ($count < $question['min_choices'] || $count > $question['max_choices'])
			{
				throw new ApiError(400, 'invalid_choice', Auth::lang('msg_check_poll_item'));
			}
		}
		if ($picked)
		{
			throw new ApiError(400, 'invalid_choice', Auth::lang('msg_check_poll_item'));
		}

		// 앱 요청은 쿠키가 없어 CSRF 와 무관하다: 비회원 투표도 엔진의 같은 사이트 요청 검사를 통과시킨다
		Board::$allowGuestWrite = true;
		try
		{
			Board::run('', 'procPoll', array(
				'module' => 'poll',
				'poll_srl' => $poll_srl,
				'poll_srl_indexes' => implode(',', $selected) . ',',
			), false, true);
		}
		catch (ApiError $e)
		{
			// 이미 참여함 등 엔진이 거절한 이유를 그대로
			throw new ApiError(400, 'vote_failed', $e->getMessage());
		}
		return array('poll' => self::info($poll_srl));
	}
}
