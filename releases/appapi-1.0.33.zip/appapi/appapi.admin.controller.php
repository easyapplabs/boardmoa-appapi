<?php
/**
 * 앱 연동 설정 저장
 */
class appapiAdminController extends appapi
{
	function init()
	{
	}

	function procAppapiAdminInsertConfig()
	{
		$vars = Context::getRequestVars();
		$config = new stdClass;
		$config->site_name = mb_substr(trim(strip_tags((string)$vars->site_name)), 0, 100);
		$config->theme_color = preg_match('/^#[0-9a-fA-F]{6}$/', trim((string)$vars->theme_color)) ? trim($vars->theme_color) : '';
		$config->logo_url = $this->cleanUrl($vars->logo_url);
		$config->icon_url = $this->cleanUrl($vars->icon_url);
		$this->nameSettings($config, $vars);
		// 다른 회원 정보 보기 (기본 같은 그룹 회원)
		$config->member_info_view = in_array((string)$vars->member_info_view, array('group', 'member', 'admin'), true) ? (string)$vars->member_info_view : 'group';
		// 설치 현황 알리기 (기본 켬)
		$config->share_site = ((string)$vars->share_site === 'N') ? 'N' : 'Y';

		$output = getController('module')->insertModuleConfig('appapi', $config);
		if (!$output->toBool())
		{
			return $output;
		}
		$this->setMessage('success_updated');
		$this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispAppapiAdminConfig'));
	}

	/** 관리자 화면의 [업데이트]: 새 버전을 받아 서명을 확인하고 덮어쓴다 */
	function procAppapiAdminUpdate()
	{
		$logged_info = Context::get('logged_info');
		if (!$logged_info || $logged_info->is_admin !== 'Y')
		{
			return new BaseObject(-1, 'msg_not_permitted');
		}
		require_once __DIR__ . '/appapi.updater.php';
		$_SESSION['appapi_update_result'] = appapiUpdater::update();
		if (!empty($_SESSION['appapi_update_result']['ok']))
		{
			appapiUpdater::report();
		}
		$this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispAppapiAdminConfig'));
	}

	/**
	 * 이름 표시 (lib/Names.php): 작성자 기본값 name_display·게시판별 board_name_display(module_srl => 값, 고르지 않은 게시판은 넣지 않음),
	 * 추천인 voter_same(Y 작성자와 같게 / N 따로)·voter_name_display·voter_board_name_display, 쪽지·친구 message_name_display(고르지 않으면 비움).
	 * 예전 값(author_name·voter_name)은 그대로 둔다(예전 모듈로 되돌려도 같게).
	 * 가입 때 이름을 받지 않는 사이트는 고르는 칸이 없으니 저장된 값을 그대로 둔다.
	 */
	private function nameSettings($config, $vars)
	{
		require_once __DIR__ . '/lib/Names.php';
		$saved = getModel('module')->getModuleConfig('appapi');
		$saved = is_object($saved) ? $saved : new stdClass;
		$keys = array('name_display', 'board_name_display', 'voter_same', 'voter_name_display', 'voter_board_name_display', 'message_name_display');
		foreach (array('author_name', 'voter_name') as $key)
		{
			if (isset($saved->$key) && appapiNames::valid($saved->$key))
			{
				$config->$key = (string)$saved->$key;
			}
		}
		if (!appapiNames::collectsUserName() || !isset($vars->name_display))
		{
			foreach ($keys as $key)
			{
				if (isset($saved->$key))
				{
					$config->$key = $saved->$key;
				}
			}
			return;
		}
		$boards = array();
		$args = new stdClass;
		$args->module = 'board';
		foreach ((array)getModel('module')->getMidList($args) as $board)
		{
			$boards[(int)$board->module_srl] = true;
		}
		// 줄마다 라디오 단추 무리 <이름>[번호]: 고른 줄만 온다, 안 온 줄은 기본값
		$pick = function ($name) use ($vars, $boards) {
			$result = array();
			$posted = isset($vars->$name) ? $vars->$name : array();
			foreach ((is_array($posted) || is_object($posted)) ? (array)$posted : array() as $srl => $mode)
			{
				if (isset($boards[(int)$srl]) && appapiNames::valid($mode))
				{
					$result[(int)$srl] = (string)$mode;
				}
			}
			return $result;
		};
		$config->name_display = appapiNames::valid($vars->name_display) ? (string)$vars->name_display : appapiNames::NICK;
		$config->board_name_display = $pick('board_names');
		$config->voter_same = (isset($vars->voter_same) && $vars->voter_same === 'N') ? 'N' : 'Y';
		// '같게'를 켜도 추천인만의 값은 남겨 둔다 (다시 끄면 그대로 보인다)
		$config->voter_name_display = (isset($vars->voter_name_display) && appapiNames::valid($vars->voter_name_display)) ? (string)$vars->voter_name_display : appapiNames::NICK;
		$config->voter_board_name_display = $pick('voter_board_names');
		$config->message_name_display = (isset($vars->message_name_display) && appapiNames::valid($vars->message_name_display)) ? (string)$vars->message_name_display : '';
	}

	/** http(s) 주소 또는 사이트 안 경로(/files/...)만 받는다 */
	private function cleanUrl($url)
	{
		$url = trim((string)$url);
		return (preg_match('#^https?://[^\s"<>]+$#i', $url) || preg_match('#^/[^\s"<>]*$#', $url)) ? $url : '';
	}
}
