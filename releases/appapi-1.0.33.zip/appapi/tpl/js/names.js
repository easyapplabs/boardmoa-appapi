/* 관리 화면 > 이름 표시: 게시판별 표(작성자·추천인)와 쪽지·친구 라디오 단추.
 * - 고르지 않으면 기본값(흐린 글씨로 '(기본: …)'). 고른 단추를 다시 누르면 풀린다(class appapi-toggle).
 * - 열 제목의 [전체]: 그 표에서 지금 보이는(찾기로 거른) 게시판을 모두 그 값으로, [전체 해제(기본값)]: 모두 기본값으로.
 * - '작성자 이름 표시와 같게'를 켜면 추천인만의 기본값·표를 숨긴다(값은 그대로 전송되어 남는다).
 * - [게시판별 작성자 이름에서 가져오기]: 작성자 이름의 기본값과 게시판별 선택을 추천인 쪽에 그대로 옮기고, 추천인 표를 펼친다.
 * - 저장은 보통 폼 전송이다(고른 줄만 <이름>[번호] 가 간다).
 * 게시판이 수백 개여도 가볍게: 이벤트는 문서에 한 번만 걸고(위임), 줄은 처음에 한 번 모아 둔다. */
function appapiNamesStart() {
	var root = document.getElementById('appapi_names');
	if (!root) return;
	var words = {};
	try { words = JSON.parse(root.getAttribute('data-text') || '{}'); } catch (e) {}
	var modes = words.modes || {};
	function t(ko, v) { return (words[ko] || ko).replace('{0}', v); }
	function checkedValue(name, fallback) {
		var on = document.querySelector('input[name="' + name + '"]:checked');
		return on ? on.value : fallback;
	}
	// 고른 단추를 다시 누르면 풀기: 무리마다 마지막으로 고른 단추를 기억한다
	var last = {};
	var toggles = root.querySelectorAll('input.appapi-toggle');
	for (var i = 0; i < toggles.length; i++) {
		if (toggles[i].checked) last[toggles[i].name] = toggles[i];
	}
	// 표마다: 기본값 라디오 이름, 줄
	var blocks = [];
	var nodes = root.querySelectorAll('.appapi-board-block');
	for (i = 0; i < nodes.length; i++) {
		var block = { el: nodes[i], defaultName: nodes[i].getAttribute('data-default'), rows: [], hint: nodes[i].querySelector('.appapi-board-hint') };
		var trs = nodes[i].querySelectorAll('tr.appapi-board');
		for (var j = 0; j < trs.length; j++) {
			var tr = trs[j];
			tr._appapiRow = { tr: tr, text: tr.getAttribute('data-search') || '', radios: tr.querySelectorAll('input[type=radio]'), effective: tr.querySelector('.appapi-effective'), block: block };
			block.rows.push(tr._appapiRow);
		}
		blocks.push(block);
	}
	function effectiveOf(row) {
		if (!row.effective) return;
		var any = false;
		for (var k = 0; k < row.radios.length; k++) any = any || row.radios[k].checked;
		row.effective.textContent = any ? '' : t('(기본: {0})', modes[checkedValue(row.block.defaultName, 'nick_name')] || '');
	}
	function refreshBlock(block) {
		for (var k = 0; k < block.rows.length; k++) effectiveOf(block.rows[k]);
		if (block.hint) block.hint.textContent = t('따로 고르지 않은 게시판에는 기본값({0})이 적용됩니다.', modes[checkedValue(block.defaultName, 'nick_name')] || '');
	}
	function refreshMessage() {
		var box = document.getElementById('appapi_message_name_display');
		var span = box && box.querySelector('.appapi-effective');
		if (span) span.textContent = box.querySelector('input:checked') ? '' : t('(기본: {0})', modes.nick_name || '');
	}
	function rowOf(el) {
		while (el && el !== root) {
			if (el._appapiRow) return el._appapiRow;
			el = el.parentNode;
		}
		return null;
	}
	function blockOf(el) {
		for (var k = 0; k < blocks.length; k++) if (blocks[k].el.contains(el)) return blocks[k];
		return null;
	}
	root.addEventListener('click', function (e) {
		var el = e.target;
		if (el.tagName === 'INPUT' && el.type === 'radio') {
			if (el.className.indexOf('appapi-toggle') !== -1) {
				if (last[el.name] === el) { el.checked = false; last[el.name] = null; } else { last[el.name] = el; }
				var row = rowOf(el);
				if (row) effectiveOf(row); else refreshMessage();
			} else {
				// 기본값 라디오: 그 기본값을 쓰는 표를 다시 그린다
				for (var k = 0; k < blocks.length; k++) if (blocks[k].defaultName === el.name) refreshBlock(blocks[k]);
			}
			return;
		}
		var value = el.getAttribute && el.getAttribute('data-all');
		if (value === null || value === undefined) return;
		var block = blockOf(el);
		if (!block) return;
		e.preventDefault();
		for (var r = 0; r < block.rows.length; r++) {
			var rw = block.rows[r];
			if (rw.tr.style.display === 'none' || !rw.radios.length) continue;
			for (var m = 0; m < rw.radios.length; m++) {
				rw.radios[m].checked = value !== '' && rw.radios[m].value === value;
				if (rw.radios[m].checked) last[rw.radios[m].name] = rw.radios[m];
			}
			if (value === '') last[rw.radios[0].name] = null;
			effectiveOf(rw);
		}
	});
	root.addEventListener('input', function (e) {
		if (!e.target.classList || !e.target.classList.contains('appapi-board-filter')) return;
		var block = blockOf(e.target);
		if (!block) return;
		var q = e.target.value.trim().toLowerCase();
		for (var r = 0; r < block.rows.length; r++) block.rows[r].tr.style.display = (q === '' || block.rows[r].text.indexOf(q) !== -1) ? '' : 'none';
		// 분류 머리줄: 그 분류에 보이는 게시판이 있을 때만
		var bodies = block.el.querySelectorAll('tbody');
		for (var b = 0; b < bodies.length; b++) {
			var head = bodies[b].querySelector('tr.appapi-group');
			if (!head) continue;
			var shown = false, items = bodies[b].querySelectorAll('tr.appapi-board');
			for (var n = 0; n < items.length && !shown; n++) shown = items[n].style.display !== 'none';
			head.style.display = shown ? '' : 'none';
		}
	});
	var copy = document.getElementById('appapi_voter_copy');
	if (copy) {
		copy.addEventListener('click', function () {
			var from = checkedValue('name_display', null);
			var to = from && root.querySelector('input[name="voter_name_display"][value="' + from + '"]');
			if (to) to.checked = true;
			for (var k = 0; k < blocks.length; k++) {
				var block = blocks[k];
				if (block.defaultName !== 'voter_name_display') continue;
				for (var r = 0; r < block.rows.length; r++) {
					var rw = block.rows[r];
					if (!rw.radios.length) continue;
					var srl = rw.radios[0].name.replace(/^voter_board_names\[|\]$/g, '');
					var src = root.querySelector('input[name="board_names[' + srl + ']"]:checked');
					last[rw.radios[0].name] = null;
					for (var m = 0; m < rw.radios.length; m++) {
						rw.radios[m].checked = !!src && rw.radios[m].value === src.value;
						if (rw.radios[m].checked) last[rw.radios[m].name] = rw.radios[m];
					}
				}
				refreshBlock(block);
				if (block.el.parentNode && block.el.parentNode.tagName === 'DETAILS') block.el.parentNode.open = true;
			}
			var done = document.getElementById('appapi_voter_copy_done');
			if (done) done.textContent = t('설정을 복사했습니다. [저장]을 눌러야 적용됩니다.', '');
		});
	}
	var same = document.getElementById('appapi_voter_same');
	var own = document.getElementById('appapi_voter_own');
	if (same && own) {
		same.addEventListener('change', function () { own.style.display = same.checked ? 'none' : ''; });
	}
}
if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', appapiNamesStart);
} else {
	appapiNamesStart();
}
