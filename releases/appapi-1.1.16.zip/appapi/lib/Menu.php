<?php
namespace AppApi;

/**
 * 사이트 정보와 메뉴.
 *
 * 메뉴는 시작 모듈의 PC 레이아웃에 연결된 메뉴 캐시(files/cache/menu/<srl>.php)를 읽는다.
 * 캐시 파일이 Context 의 logged_info 로 그룹별 표시 여부를 계산하므로, 로그인 상태를 만든 뒤 읽어야 한다.
 */
class Menu
{
	public static function site()
	{
		$index = self::indexModule();
		$name = Core::config('site_name') ?: ($index ? $index->browser_title : $_SERVER['HTTP_HOST']);
		return array(
			'name' => Core::plainLang($name),
			// 이름이 다국어면 언어별 이름 (1.0.13~, 앱 언어 코드 => 이름). 설치 현황 서버가 추천 사이트 목록에 옮겨 쓴다
			'names' => self::siteNames($name),
			// 관리 화면 '개발자에게 알리기' (1.0.14~). 끄면 설치 현황 서버가 이 사이트를 목록에 넣지 않고 있던 줄도 지운다
			'share_site' => self::shareSite(),
			'base_url' => Core::$base_url,
			'theme_color' => Core::config('theme_color') ?: null,
			'logo_url' => self::logoUrl($index),
			'icon_url' => self::iconUrl(),
			'home_mid' => $index ? $index->mid : null,
			// 첫 화면이 페이지 모듈인지 (1.1.0~). 참이면 앱의 '페이지로 보기'가 홈에 이 페이지를 보여 줄 수 있다
			'home_is_page' => $index && $index->module === 'page',
			'engine' => Core::$engine,
			'engine_version' => defined('RX_VERSION') ? RX_VERSION : (defined('__XE_VERSION__') ? __XE_VERSION__ : null),
			'api_version' => APPAPI_VERSION,
			// 내용 언어 (모듈 0.10.19~): 앱이 보낸 X-App-Lang 을 사이트가 켜 두었으면 그 언어, 아니면 사이트 기본 언어
			'lang' => (string)\Context::getLangType(),
			// 이 모듈이 할 줄 아는 것 (앱은 여기 있을 때만 그 기능을 쓴다. 예전 모듈엔 없어서 예전 방식으로 동작)
			'features' => self::features(),
			'member' => Auth::profile(),
		);
	}

	/** 관리 화면 '개발자에게 알리기' (기본 켬, appapi.updater.php 와 같은 설정) */
	private static function shareSite()
	{
		$config = getModel('module')->getModuleConfig('appapi');
		return !(is_object($config) && isset($config->share_site) && $config->share_site === 'N');
	}

	/**
	 * 다국어 이름($user_lang->열쇠)의 언어별 값: 앱 언어 코드(ko en ja es pt-BR de fr it vi id zh-Hant zh-Hans) => 이름.
	 * 다국어가 아니거나 언어가 하나뿐이면 null.
	 */
	private static function siteNames($text)
	{
		$text = (string)$text;
		if (!preg_match_all('/\$user_lang->([a-zA-Z0-9_]+)/', $text, $m))
		{
			return null;
		}
		$values = array(); // 앱 언어 코드 => 열쇠 => 값
		foreach (array_unique($m[1]) as $key)
		{
			$args = new \stdClass();
			$args->site_srl = 0;
			$args->name = $key;
			$output = executeQueryArray('module.getLang', $args);
			if (!$output->toBool() || !$output->data)
			{
				continue;
			}
			foreach ($output->data as $row)
			{
				$code = Core::appLangCode($row->lang_code);
				if ($code !== null && trim((string)$row->value) !== '')
				{
					$values[$code][$key] = (string)$row->value;
				}
			}
		}
		$names = array();
		foreach ($values as $code => $byKey)
		{
			// 이름 속 열쇠가 모두 그 언어 값이 있을 때만
			if (count($byKey) !== count(array_unique($m[1])))
			{
				continue;
			}
			$value = preg_replace_callback('/\$user_lang->([a-zA-Z0-9_]+)/', function ($x) use ($byKey) { return $byKey[$x[1]]; }, $text);
			$names[$code] = trim(html_entity_decode(strip_tags($value), ENT_QUOTES, 'UTF-8'));
		}
		return count($names) > 1 ? $names : null;
	}

	/**
	 * 모듈이 지원하는 기능 이름 (docs/API.md '기능 목록').
	 * html_write: 새 글을 꾸밈 HTML 로 받는다(document.write content_format=html)
	 * polls: 글 속 투표를 데이터로 주고(document.polls) 투표를 받는다(poll.vote)
	 * extra_vars: 게시판 추가 항목 정의(board.extra_keys)를 주고 글쓰기·고치기에서 값(extra_vars)을 받는다
	 * media_html: document 에 with_media=1 을 주면 멀티미디어·이미지 갤러리 부품을 보통 HTML 로 바꾼다
	 * captcha_solve: CAPTCHA 위젯 정보(board.captcha_widget·signup.form captcha_widget·error.captcha)를 주고,
	 *   앱이 푼 답(captcha_response)을 엔진의 CAPTCHA 확인에 넘긴다. 앱 로그인도 로그인 CAPTCHA 를 확인한다
	 * guest_write: 비회원도 글쓰기 권한이 있으면 document.write 를 받는다(board.guest_fields 의 이름·비밀번호), 사진 첨부도 웹과 같은 판단
	 * edit_photos: document.update 가 새 사진(multipart photos[])을 받아 그 글에 첨부로 붙이고 본문 끝에 넣는다
	 * guest_manage: 비회원 글·댓글을 비밀번호로 고치고 지우며(password_edit), 비회원 비밀글을 비밀번호로 연다(password_view)
	 * guest_comment: 비회원도 댓글 권한이 있으면 comment.write 를 받는다(board.guest_comment_fields 의 이름·비밀번호)
	 * comment_edit: comment.update 로 댓글을 고친다(댓글의 can_edit)
	 * unlocked_comment: 비밀번호로 연 비회원 비밀글에 댓글을 단다. 글 응답의 comment_document_password 가 참이면
	 *   comment.write 에 그 글의 비밀번호를 document_password 로 같이 보낸다(웹이 비밀번호 확인 뒤 댓글을 받는 것과 같다)
	 * page_view: page 에 with_css=1 을 주면 그 페이지가 쓰는 사이트 CSS 주소(css)를 더해 준다. 앱의 '페이지로 보기'
	 * password_throttle: 비회원 글·댓글 비밀번호를 같은 곳(IP)에서 10분 동안 10번 틀리면 그 글·댓글은 429 too_many_attempts
	 */
	public static function features()
	{
		return array('html_write', 'polls', 'extra_vars', 'media_html', 'captcha_solve', 'guest_write', 'edit_photos', 'guest_manage', 'guest_comment', 'comment_edit', 'unlocked_comment', 'password_throttle', 'comment_vote', 'file_upload', 'devices', 'page_view');
	}

	/**
	 * 메뉴에 있는 게시판 mid 전부 (모아 보기 기본 대상).
	 */
	public static function boardMids()
	{
		$mids = array();
		$walk = function ($items) use (&$walk, &$mids) {
			foreach ($items as $item)
			{
				if ($item['module'] === 'board')
				{
					$mids[] = $item['mid'];
				}
				$walk($item['children']);
			}
		};
		foreach (self::menus()['menus'] as $menu)
		{
			$walk($menu['items']);
		}
		return array_values(array_unique($mids));
	}

	public static function menus()
	{
		$index = self::indexModule();
		$layout_srl = self::resolveLayout($index ? (int)$index->layout_srl : -1);
		$used = array();
		$menus = self::layoutMenus($layout_srl, $used);
		// 게시판들이 쓰는 레이아웃의 메뉴도 함께 모은다 (1.1.13~): 첫 화면만 다른 레이아웃(소개·랜딩 화면)이거나,
		// 게시판들이 따로 왼쪽 메뉴 레이아웃을 쓰는 사이트는 메인 메뉴가 게시판 쪽 레이아웃에만 있다. 같은 메뉴는 한 번만
		foreach (self::boardLayouts() as $srl)
		{
			if ($srl !== $layout_srl)
			{
				$menus = array_merge($menus, self::layoutMenus($srl, $used));
			}
		}
		// 앱(예전 앱 포함)은 첫 메뉴만 그린다: 게시판이 가장 많은 메뉴를 맨 앞으로 (같으면 원래 순서 — 보통 사이트는 그대로)
		$best = 0;
		$best_count = self::countBoards($menus ? $menus[0]['items'] : array());
		foreach ($menus as $i => $menu)
		{
			$count = self::countBoards($menu['items']);
			if ($count > $best_count)
			{
				$best = $i;
				$best_count = $count;
			}
		}
		if ($best > 0)
		{
			$menu = $menus[$best];
			array_splice($menus, $best, 1);
			array_unshift($menus, $menu);
		}
		// 첫 메뉴에 없는 게시판 중 이 회원이 읽을 수 있는 것 (관리 화면에서 끌 수 있다, 1.1.8~)
		if (Core::config('other_boards') !== 'N')
		{
			// 앱은 첫 메뉴만 그리므로 첫 메뉴에 없는 게시판 (다른 메뉴에만 있는 게시판도 앱에서 보이게).
			// 웹에서 찾아갈 수 있는 게시판만 (1.1.15~): 어느 메뉴에도 없고 첫 화면도 가리키지 않는 게시판(끝난 행사·배너·시험용)은 웹처럼 감춘다
			$others = self::otherBoards($menus ? array($menus[0]) : array(), self::reachableMids($menus));
			if ($others)
			{
				// 앱(예전 앱 포함)은 첫 메뉴만 그린다: 첫 메뉴 끝에 묶음으로, 메뉴가 없으면 이 목록이 첫 메뉴
				if ($menus)
				{
					$menus[0]['items'][] = array(
						'title' => \appapiText::t('그 밖의 게시판'), 'mid' => null, 'module' => null, 'grant' => null,
						'url' => null, 'open_window' => false, 'children' => $others,
					);
				}
				$menus[] = array('id' => 'boards', 'title' => \appapiText::t('게시판'), 'items' => $others);
			}
		}
		return array('menus' => $menus);
	}

	/** 레이아웃 번호: 0·-1(기본 레이아웃 따름)이면 사이트 디자인의 PC 기본 레이아웃 */
	private static function resolveLayout($layout_srl)
	{
		if ($layout_srl <= 0)
		{
			$layout_srl = (int)getAdminModel('layout')->getSiteDefaultLayout('P');
		}
		return $layout_srl;
	}

	/** 레이아웃에 연결된 메뉴들 ($used: 이미 넣은 메뉴 번호, 같은 메뉴를 두 번 넣지 않는다) */
	private static function layoutMenus($layout_srl, array &$used)
	{
		$layout = $layout_srl > 0 ? getModel('layout')->getLayout($layout_srl) : null;
		$menus = array();
		if ($layout && !empty($layout->menu))
		{
			foreach ($layout->menu as $menu_id => $menu)
			{
				$menu_srl = (int)$menu->menu_srl;
				if ($menu_srl <= 0 || isset($used[$menu_srl]))
				{
					continue;
				}
				$used[$menu_srl] = true;
				$items = self::loadMenuCache($menu_srl);
				if (!$items)
				{
					continue;
				}
				$menus[] = array(
					'id' => $menu_id,
					'title' => $menu->title ?? $menu_id,
					'items' => $items,
				);
			}
		}
		return $menus;
	}

	private static function countBoards(array $items)
	{
		$count = 0;
		foreach ($items as $item)
		{
			if (($item['module'] ?? null) === 'board')
			{
				$count++;
			}
			$count += self::countBoards($item['children'] ?? array());
		}
		return $count;
	}

	/** 이 사이트의 게시판 모듈 정보 (게시판 번호 순) */
	private static function siteBoards()
	{
		static $boards = null;
		if ($boards === null)
		{
			$boards = array();
			$site = \Context::get('site_module_info');
			$args = new \stdClass;
			$args->site_srl = ($site && isset($site->site_srl)) ? (int)$site->site_srl : 0;
			foreach (Core::listOf(getModel('module')->getMidList($args)) as $info)
			{
				if (($info->module ?? '') === 'board' && !empty($info->mid))
				{
					$boards[(int)$info->module_srl] = $info;
				}
			}
			ksort($boards);
		}
		return $boards;
	}

	/** 게시판들이 쓰는 레이아웃 (많이 쓰는 것부터) */
	private static function boardLayouts()
	{
		$count = array();
		foreach (self::siteBoards() as $info)
		{
			$srl = self::resolveLayout((int)($info->layout_srl ?? -1));
			if ($srl > 0)
			{
				$count[$srl] = ($count[$srl] ?? 0) + 1;
			}
		}
		arsort($count);
		return array_keys($count);
	}

	/**
	 * 웹에서 찾아갈 수 있는 게시판 mid: 앱이 모은 메뉴(첫 화면·게시판 레이아웃에 연결된 메뉴) 어디에든 있거나,
	 * 첫 화면 페이지의 위젯(module_srls·mid_list)·링크가 가리키는 게시판
	 */
	private static function reachableMids(array $menus)
	{
		$mids = array();
		$walk = function ($items) use (&$walk, &$mids) {
			foreach ($items as $item)
			{
				if (!empty($item['mid']))
				{
					$mids[$item['mid']] = true;
				}
				$walk($item['children'] ?? array());
			}
		};
		foreach ($menus as $menu)
		{
			$walk($menu['items']);
		}
		$index = self::indexModule();
		if (!$index)
		{
			return $mids;
		}
		$html = (string)($index->content ?? '') . (string)($index->mcontent ?? '');
		// 글 꼴 페이지는 본문 글
		if (($index->page_type ?? '') === 'ARTICLE')
		{
			foreach (array('document_srl', 'mdocument_srl') as $key)
			{
				if (!empty($index->$key))
				{
					$document = getModel('document')->getDocument((int)$index->$key, false, false);
					if ($document && $document->isExists())
					{
						$html .= (string)$document->get('content');
					}
				}
			}
		}
		if ($html === '')
		{
			return $mids;
		}
		$oModuleModel = getModel('module');
		if (preg_match_all('/module_srls?\s*=\s*["\']([0-9,\s]+)["\']/i', $html, $m))
		{
			foreach ($m[1] as $list)
			{
				foreach (preg_split('/[,\s]+/', $list, -1, PREG_SPLIT_NO_EMPTY) as $srl)
				{
					$info = $oModuleModel->getModuleInfoByModuleSrl((int)$srl);
					if ($info && !empty($info->mid))
					{
						$mids[$info->mid] = true;
					}
				}
			}
		}
		if (preg_match_all('/mid_list\s*=\s*["\']([^"\']+)["\']/i', $html, $m))
		{
			foreach ($m[1] as $list)
			{
				foreach (preg_split('/[,\s]+/', $list, -1, PREG_SPLIT_NO_EMPTY) as $mid)
				{
					$mids[$mid] = true;
				}
			}
		}
		if (preg_match_all('/href\s*=\s*["\']([^"\'#]+)["\']/i', $html, $m))
		{
			foreach ($m[1] as $url)
			{
				$mid = self::internalMid($url);
				if ($mid !== null)
				{
					$mids[$mid] = true;
				}
			}
		}
		return $mids;
	}

	/** 첫 메뉴에 없는 게시판 중 웹에서 찾아갈 수 있고($reachable) 이 회원이 목록을 볼 수 있는 것 */
	private static function otherBoards(array $menus, array $reachable)
	{
		$placed = array();
		$walk = function ($items) use (&$walk, &$placed) {
			foreach ($items as $item)
			{
				if (!empty($item['mid']))
				{
					$placed[$item['mid']] = true;
				}
				$walk($item['children'] ?? array());
			}
		};
		foreach ($menus as $menu)
		{
			$walk($menu['items']);
		}
		$items = array();
		foreach (self::siteBoards() as $info)
		{
			if (isset($placed[$info->mid]) || !isset($reachable[$info->mid]))
			{
				continue;
			}
			$module_info = getModel('module')->getModuleInfoByMid($info->mid);
			if (!$module_info || $module_info->module !== 'board' || !Board::isVisible($module_info))
			{
				continue;
			}
			$g = Board::grant($module_info);
			$title = trim(html_entity_decode(strip_tags(Core::userLang((string)($module_info->browser_title ?? ''))), ENT_QUOTES, 'UTF-8'));
			$items[] = array(
				'title' => $title !== '' ? $title : $module_info->mid,
				'mid' => $module_info->mid,
				'module' => 'board',
				'grant' => array(
					'view' => (bool)$g->view,
					'write_document' => (bool)$g->write_document,
					'write_comment' => (bool)$g->write_comment,
				),
				'url' => Core::$base_url . $module_info->mid,
				'open_window' => false,
				'children' => array(),
			);
		}
		return $items;
	}

	/**
	 * 사이트 로고: config.php 의 logo_url → 시작 모듈 레이아웃의 로고 이미지 변수(logo_image 등).
	 */
	private static function logoUrl($index)
	{
		if (Core::config('logo_url'))
		{
			return Core::absoluteUrl(Core::config('logo_url'));
		}
		$layout_srl = $index ? (int)$index->layout_srl : -1;
		if ($layout_srl <= 0)
		{
			$layout_srl = (int)getAdminModel('layout')->getSiteDefaultLayout('P');
		}
		$layout = $layout_srl > 0 ? getModel('layout')->getLayout($layout_srl) : null;
		if (!$layout || empty($layout->extra_var))
		{
			return null;
		}
		$candidates = array();
		foreach ($layout->extra_var as $name => $var)
		{
			if (($var->type ?? '') === 'image' && stripos($name, 'logo') !== false && !empty($var->value))
			{
				$candidates[$name] = $var->value;
			}
		}
		if (!$candidates)
		{
			return null;
		}
		$value = $candidates['logo_image'] ?? reset($candidates);
		return Core::absoluteUrl($value);
	}

	/**
	 * 사이트 아이콘(정사각형): config.php 의 icon_url → 모바일 홈 아이콘 → 파비콘.
	 */
	private static function iconUrl()
	{
		if (Core::config('icon_url'))
		{
			return Core::absoluteUrl(Core::config('icon_url'));
		}
		foreach (array('files/attach/xeicon/mobicon.png', 'files/attach/xeicon/favicon.ico') as $file)
		{
			if (file_exists('./' . $file))
			{
				return Core::$base_url . $file;
			}
		}
		return null;
	}

	private static function indexModule()
	{
		$site = \Context::get('site_module_info');
		if (!$site)
		{
			return null;
		}
		// Rhymix: 도메인 정보에 index_module_srl / 구 XE: 시작 모듈 정보 자체
		$module_srl = isset($site->index_module_srl) ? (int)$site->index_module_srl : (int)$site->module_srl;
		return $module_srl ? getModel('module')->getModuleInfoByModuleSrl($module_srl) : null;
	}

	private static function loadMenuCache($menu_srl)
	{
		$file = './files/cache/menu/' . $menu_srl . '.php';
		if (!file_exists($file))
		{
			getAdminController('menu')->makeXmlFile($menu_srl);
		}
		if (!file_exists($file))
		{
			return array();
		}
		$menu = null;
		include $file;
		return ($menu && !empty($menu->list)) ? self::convertItems($menu->list) : array();
	}

	/**
	 * 같은 사이트 주소(/mid, ?mid=..)에서 mid 를 뽑는다. 다른 사이트면 null.
	 */
	private static function internalMid($url)
	{
		$parts = parse_url(Core::absoluteUrl(html_entity_decode((string)$url, ENT_QUOTES, 'UTF-8')));
		// http/https, www. 유무, 모바일 주소(m.)는 같은 사이트 (앱과 같은 기준). blog. 같은 다른 하위 도메인은 다른 사이트
		$key = function ($host) {
			return preg_replace('/^(www|m)\.(?=[^.]+\.[^.]+)/', '', rtrim(strtolower((string)$host), '.'));
		};
		$site_host = $key(parse_url(Core::$base_url, PHP_URL_HOST));
		if (empty($parts['host']) || $key($parts['host']) !== $site_host)
		{
			return null;
		}
		if (!empty($parts['query']))
		{
			parse_str($parts['query'], $query);
			if (!empty($query['mid']) && is_string($query['mid']))
			{
				return $query['mid'];
			}
		}
		// 짧은 주소: /mid, 그리고 Rhymix·XE 가 쓰는 /mid/category/3, /mid/page/2, /mid/123 처럼 뒤가 붙은 꼴(1.1.11~).
		// 사이트가 하위 폴더에 있으면 그 폴더를 뗀다. 그 이름의 모듈이 실제로 있는지는 부르는 쪽이 본다
		$path = (string)($parts['path'] ?? '');
		$base_path = rtrim((string)parse_url(Core::$base_url, PHP_URL_PATH), '/');
		if ($base_path !== '' && strpos($path, $base_path . '/') === 0)
		{
			$path = substr($path, strlen($base_path));
		}
		if (preg_match('#^/([a-zA-Z][a-zA-Z0-9_]*)(?:/|$)#', $path, $m))
		{
			return $m[1];
		}
		return null;
	}

	/** 바로가기 주소가 글 하나(?document_srl=, /mid/123)나 특정 동작(?act=글쓰기 등)을 가리키는지 */
	private static function pointsToDocument($url)
	{
		// 메뉴 캐시의 주소는 &amp; 로 저장된다
		$parts = parse_url(Core::absoluteUrl(html_entity_decode((string)$url, ENT_QUOTES, 'UTF-8')));
		if (!empty($parts['query']))
		{
			parse_str($parts['query'], $query);
			if (!empty($query['document_srl']) || !empty($query['act']))
			{
				return true;
			}
		}
		// /123 이나 /mid/123 (글 짧은 주소). /mid/category/0 같은 분류·쪽 주소는 아니다
		$path = (string)($parts['path'] ?? '');
		$base_path = rtrim((string)parse_url(Core::$base_url, PHP_URL_PATH), '/');
		if ($base_path !== '' && strpos($path, $base_path . '/') === 0)
		{
			$path = substr($path, strlen($base_path));
		}
		return (bool)preg_match('#^/(?:[a-zA-Z][a-zA-Z0-9_]*/)?\d+/?$#', $path);
	}

	private static function convertItems($list)
	{
		$items = array();
		foreach ((array)$list as $node)
		{
			if (empty($node['isShow']) || (string)$node['text'] === '')
			{
				continue;
			}
			$url = (string)$node['url'];
			$is_mid = $url !== '' && $node['is_shortcut'] !== 'Y' && preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $url);
			$children = self::convertItems($node['list'] ?? array());
			$had_children = !empty($node['list']);
			$module = null;
			$grant = null;
			// 바로가기 링크가 같은 사이트의 게시판을 가리키면 그 게시판 권한으로 거른다
			if (!$is_mid && $url !== '' && ($linked = self::internalMid($url)) !== null)
			{
				$linked_info = getModel('module')->getModuleInfoByMid($linked);
				if ($linked_info && !Board::isVisible($linked_info) && !$children)
				{
					continue;
				}
				// 같은 사이트의 게시판·페이지 첫 화면을 가리키는 바로가기(/review, /review/category/0, ?mid=review&page=2)는
				// 그 게시판·페이지 항목으로: 앱이 게시판 화면으로 열고, 메뉴에 게시판이 있는 것으로 센다(1.1.11~). 글 하나를 가리키면 링크 그대로
				if ($linked_info && in_array($linked_info->module, array('board', 'page'), true) && !self::pointsToDocument($url))
				{
					$url = $linked;
					$is_mid = true;
				}
			}
			// 링크 없는 묶음 제목('#' 바로가기)인데 하위가 모두 권한 밖이면 빈 묶음만 남으므로 뺀다
			if (!$is_mid && $had_children && !$children && ($url === '' || $url[0] === '#'))
			{
				continue;
			}
			if ($is_mid)
			{
				$module_info = getModel('module')->getModuleInfoByMid($url);
				if (!$module_info || !Board::isVisible($module_info))
				{
					// 권한이 없는 게시판·페이지는 빼고, 하위에 볼 수 있는 항목이 있으면 묶음 제목으로만 남긴다
					if (!$children)
					{
						continue;
					}
					$is_mid = false;
					$url = '';
				}
				elseif ($module_info->module === 'page' && $had_children && !$children)
				{
					// 하위 게시판 묶음의 대표 페이지인데 하위가 모두 권한 밖이면 숨긴다.
					// 이런 페이지는 보통 하위 게시판의 최신글 위젯을 보여 주므로, 권한 없는 글 제목이 드러난다.
					continue;
				}
				else
				{
					$module = $module_info->module;
					if ($module === 'board')
					{
						$g = Board::grant($module_info);
						$grant = array(
							'view' => (bool)$g->view,
							'write_document' => (bool)$g->write_document,
							'write_comment' => (bool)$g->write_comment,
						);
					}
				}
			}
			$items[] = array(
				'title' => html_entity_decode(strip_tags(Core::userLang((string)$node['text'])), ENT_QUOTES, 'UTF-8'),
				'mid' => $is_mid ? $url : null,
				'module' => $module,
				'grant' => $grant,
				'url' => $is_mid ? Core::$base_url . $url : ($url !== '' ? Core::absoluteUrl(html_entity_decode($url, ENT_QUOTES, 'UTF-8')) : null),
				'open_window' => $node['open_window'] === 'Y',
				'children' => $children,
			);
		}
		return $items;
	}
}
