<?php
/**
 * 앱에 보내는 회원 이름 (글·댓글 작성자, 추천인 등). API(lib/Core.php)와 관리 화면이 같이 쓴다.
 *
 * - 사이트가 가입 때 이름(user_name)을 받지 않으면(회원 설정 > 가입 양식에서 '이름'을 쓰지 않음) 언제나 닉네임만.
 *   저장된 이름 설정은 무시한다(지우지는 않는다: 나중에 이름을 받게 되면 다시 쓰인다).
 * - 익명 게시판(use_anonymous)은 언제나 닉네임 그대로(엔진이 넣은 익명 이름). 이름을 드러내지 않는다.
 * - 작성자(author): 게시판마다 닉네임 / 이름 / 닉네임(이름)(board_name_display), 고르지 않은 게시판은 작성자 기본값(name_display).
 *   기본값도 고르지 않으면(처음 상태) 웹 사이트와 같은 닉네임.
 * - 추천인(voter): '작성자 이름 표시와 같게'(voter_same, 기본 켬)면 그 게시판의 작성자 값. 끄면 추천인만의 게시판별 값
 *   (voter_board_name_display)과 기본값(voter_name_display, 고르지 않으면 닉네임).
 * - 쪽지·친구·쪽지 알림(message): 따로 고른다(message_name_display). 고르지 않으면 엔진과 같은 닉네임.
 * - 예전 설정(1.0.2 까지: author_name 작성자 이름 표시, voter_name 추천인 이름 표시, 닉네임만/닉네임(이름)): 새 설정을 저장하기 전까지는
 *   그대로 따른다. 작성자 기본값은 예전 작성자 값, 예전 추천인 값을 작성자 값과 다르게 저장해 둔 사이트는 '같게'를 끄고
 *   추천인 기본값을 예전 추천인 값으로 시작한다(그 밖에는 '같게' 켬).
 * - 이름: 회원에게 이름이 없으면 닉네임. 닉네임(이름): 이름이 있고 닉네임과 다를 때만 붙인다. 비회원은 쓴 이름 그대로.
 * PHP 7.1 문법만 쓴다.
 */
class appapiNames
{
	const NICK = 'nick_name';
	const NAME = 'user_name';
	const BOTH = 'nick_name_user_name';

	public static function modes()
	{
		return array(self::NICK, self::NAME, self::BOTH);
	}

	public static function valid($mode)
	{
		return in_array((string)$mode, self::modes(), true);
	}

	/** 가입 양식에서 이름(user_name)을 받는 사이트인가 (회원 설정 signupForm 의 user_name 을 쓰는가) */
	public static function collectsUserName()
	{
		static $result = null;
		if ($result === null)
		{
			$result = false;
			$config = getModel('member')->getMemberConfig();
			foreach ((array)(is_object($config) && isset($config->signupForm) ? $config->signupForm : array()) as $item)
			{
				if (is_object($item) && isset($item->name) && $item->name === 'user_name')
				{
					$result = !empty($item->isUse);
				}
			}
		}
		return $result;
	}

	/** 저장된 설정에서 게시판별 값 (module_srl => 값, 고르지 않은 게시판은 없음). $scope: author | voter */
	public static function boardModes($config, $scope = 'author')
	{
		$result = array();
		$key = $scope === 'voter' ? 'voter_board_name_display' : 'board_name_display';
		$boards = isset($config[$key]) ? $config[$key] : null;
		foreach ((array)$boards as $srl => $mode)
		{
			if ((int)$srl > 0 && self::valid($mode))
			{
				$result[(int)$srl] = (string)$mode;
			}
		}
		return $result;
	}

	/** 예전 값(닉네임만 / 닉네임(이름)) → 방식 */
	private static function legacy($config, $key)
	{
		return (isset($config[$key]) && (string)$config[$key] === self::BOTH) ? self::BOTH : self::NICK;
	}

	/** 추천인 이름을 작성자 이름 표시와 같게 하는가 (voter_same, 저장 전이면 예전 값으로 정한다) */
	public static function voterSame($config)
	{
		$same = isset($config['voter_same']) ? (string)$config['voter_same'] : '';
		if ($same === 'Y' || $same === 'N')
		{
			return $same === 'Y';
		}
		$voter = isset($config['voter_name']) ? (string)$config['voter_name'] : '';
		return !(self::valid($voter) && $voter !== self::legacy($config, 'author_name'));
	}

	/**
	 * 관리자가 고른 기본값 (게시판에서 고르지 않은 곳). $scope: author | voter (voter 는 '같게'를 끈 때의 추천인 기본값)
	 * 고르지 않았으면 '' (웹 사이트와 같은 닉네임, mode() 가 NICK 으로 바꾼다).
	 * @param array $config 저장된 설정
	 */
	public static function siteDefault($config, $scope)
	{
		$key = $scope === 'voter' ? 'voter_name_display' : 'name_display';
		if (isset($config[$key]))
		{
			// 새 설정을 저장한 사이트: 고른 값, 고르지 않고 저장했으면 ''
			return self::valid($config[$key]) ? (string)$config[$key] : '';
		}
		// 새 설정을 아직 저장하지 않은 사이트: 예전 설정을 저장해 두었으면 그 값
		$legacy = $scope === 'voter' ? 'voter_name' : 'author_name';
		return (isset($config[$legacy]) && self::valid($config[$legacy])) ? self::legacy($config, $legacy) : '';
	}

	/**
	 * 게시판의 이름 표시 방식.
	 * @param array $config 저장된 설정
	 * @param object|null $module_info 게시판 정보 (게시판이 아니거나 모르면 null → 기본값)
	 * @param string $scope author | voter | message (쪽지·친구)
	 */
	public static function mode($config, $module_info, $scope)
	{
		if (!self::collectsUserName())
		{
			return self::NICK;
		}
		// 쪽지·친구(엔진의 쪽지 모듈): 따로 고른 값, 고르지 않으면 엔진과 같은 닉네임
		if ($scope === 'message')
		{
			$mode = isset($config['message_name_display']) ? (string)$config['message_name_display'] : '';
			return self::valid($mode) ? $mode : self::NICK;
		}
		if ($module_info && isset($module_info->use_anonymous) && $module_info->use_anonymous === 'Y')
		{
			return self::NICK;
		}
		if ($scope === 'voter' && self::voterSame($config))
		{
			$scope = 'author';
		}
		$srl = $module_info ? (int)$module_info->module_srl : 0;
		$boards = self::boardModes($config, $scope);
		if ($srl && isset($boards[$srl]))
		{
			return $boards[$srl];
		}
		$default = self::siteDefault($config, $scope);
		return $default !== '' ? $default : self::NICK;
	}

	/** 방식에 따라 이름을 만든다 */
	public static function format($mode, $nick_name, $user_name)
	{
		$nick_name = (string)$nick_name;
		$user_name = trim((string)$user_name);
		if ($mode === self::NAME)
		{
			return $user_name !== '' ? $user_name : $nick_name;
		}
		if ($mode === self::BOTH && $user_name !== '' && $user_name !== $nick_name)
		{
			return $nick_name . '(' . $user_name . ')';
		}
		return $nick_name;
	}
}
