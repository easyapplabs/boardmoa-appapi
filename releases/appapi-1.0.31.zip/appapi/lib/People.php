<?php
namespace AppApi;

/**
 * 글쓴이 이름을 눌렀을 때의 메뉴: 회원 정보 보기, 작성글 보기, 쪽지 보내기, 친구 등록, 메일 보내기.
 *
 * 메뉴는 웹과 같은 엔진 함수(member 의 getMemberMenu)를 실행해 만든다. 쪽지·친구는 쪽지 모듈 설정(Rhymix)이나
 * member_communication 애드온(XE), 상대의 쪽지 받기 설정, 이미 친구인지에 따라 엔진이 붙이거나 뺀다.
 * 앱이 처리할 수 있는 항목만 골라 보낸다(관리자용 추적 메뉴 등은 뺀다).
 */
class People
{
	public static function menu()
	{
		$member_srl = Core::intParam('member_srl');
		$mid = self::mid();
		if (!$member_srl)
		{
			throw new ApiError(400, 'missing_member_srl', 'member_srl is required');
		}
		$actions = self::menuActions($member_srl, $mid);
		if (isset($actions['info']) && !self::settingAllowsInfo($member_srl))
		{
			unset($actions['info']);
		}
		return array('member_srl' => $member_srl, 'actions' => array_values($actions));
	}

	/**
	 * 관리 화면 '다른 회원 정보 보기'(1.0.5~): group = 같은 그룹 회원(기본), member = 로그인한 회원, admin = 관리자만.
	 * 관리자와 본인은 늘, 로그인하지 않은 사람은 늘 안 된다. 엔진(사이트가 바꾼 메뉴 조건 포함)의 판단과 함께 쓴다(더 좁은 쪽).
	 */
	private static function settingAllowsInfo($member_srl)
	{
		$logged_info = \Context::get('logged_info');
		if (!$logged_info || !$logged_info->member_srl)
		{
			return false;
		}
		if ($logged_info->is_admin === 'Y' || (int)$logged_info->member_srl === (int)$member_srl)
		{
			return true;
		}
		$rule = (string)Core::config('member_info_view');
		if ($rule === 'member')
		{
			return true;
		}
		if ($rule === 'admin')
		{
			return false;
		}
		$mine = array_keys((array)($logged_info->group_list ?? array()));
		$theirs = array_keys((array)getModel('member')->getMemberGroups((int)$member_srl));
		return (bool)array_intersect($mine, $theirs);
	}

	/** 엔진의 이름 메뉴(member getMemberMenu)를 실행해 앱이 할 수 있는 동작만 [type => action] */
	private static function menuActions($member_srl, $mid)
	{
		$oModule = Board::run('', 'getMemberMenu', array('module' => 'member', 'target_srl' => $member_srl, 'cur_mid' => $mid), false);
		$actions = array();
		foreach ((array)$oModule->get('menus') as $menu)
		{
			$url = html_entity_decode((string)($menu->url ?? ''), ENT_QUOTES, 'UTF-8');
			$label = strip_tags((string)($menu->str ?? ''));
			$action = self::actionFromUrl($url, $member_srl, $mid);
			if ($action)
			{
				$action['label'] = $label;
				$actions[$action['type']] = $action;
			}
		}
		return $actions;
	}

	/** 엔진이 만든 메뉴 주소를 앱 동작으로 바꾼다. 모르는 메뉴는 null */
	private static function actionFromUrl($url, $member_srl, $mid)
	{
		if (stripos($url, 'mailto:') === 0)
		{
			return array('type' => 'email', 'email' => substr($url, 7));
		}
		$query = array();
		parse_str((string)parse_url($url, PHP_URL_QUERY), $query);
		$act = isset($query['act']) ? (string)$query['act'] : '';
		if ($act === 'dispMemberInfo')
		{
			return array('type' => 'info');
		}
		if ($act === 'dispCommunicationSendMessage')
		{
			return array('type' => 'message');
		}
		if ($act === 'dispCommunicationAddFriend')
		{
			return array('type' => 'friend');
		}
		// 작성글 보기: Rhymix 는 ?mid=..&member_srl=.., XE 는 ?mid=..&search_target=nick_name&search_keyword=..
		// 짧은 주소를 쓰는 사이트는 게시판 이름이 경로에 있다 (/conf_schedule?member_srl=..)
		if (empty($query['mid']))
		{
			$path = trim((string)parse_url($url, PHP_URL_PATH), '/');
			$last = $path === '' ? '' : basename($path);
			if (preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $last) && $last !== 'index')
			{
				$query['mid'] = $last;
			}
		}
		if ($act === '' && !empty($query['mid']) && (!empty($query['member_srl']) || (($query['search_target'] ?? '') === 'nick_name' && isset($query['search_keyword']))))
		{
			$search = !empty($query['member_srl'])
				? array('member_srl' => (string)(int)$query['member_srl'])
				: array('search_target' => 'nick_name', 'search_keyword' => (string)$query['search_keyword']);
			return array('type' => 'documents', 'mid' => (string)$query['mid'], 'search' => $search);
		}
		return null;
	}

	/** 회원 정보: 웹과 같은 엔진 함수로, 관리자가 공개로 정한 항목만 (자기 정보·관리자는 엔진 규칙대로) */
	public static function info()
	{
		$member_srl = Core::intParam('member_srl');
		if (!$member_srl)
		{
			throw new ApiError(400, 'missing_member_srl', 'member_srl is required');
		}
		// 남의 정보는 관리 화면 설정(같은 그룹 회원 기본)이 허락하고, 엔진의 이름 메뉴에도 '회원 정보 보기'가 있을 때만 (1.0.5~). 엔진 기본은 '로그인한 회원'이지만,
		// 사이트가 메뉴 조건을 바꿨으면(kgpa: 관리자이거나 같은 그룹을 함께 가진 회원만) 그 판단을 그대로 따른다.
		// 웹은 메뉴만 숨기고 주소를 직접 열면 보이지만, API 는 메뉴를 거치지 않은 요청도 같은 기준으로 막는다.
		$logged_info = \Context::get('logged_info');
		if (!$logged_info || !$logged_info->member_srl)
		{
			throw new ApiError(401, 'login_required', Auth::lang('msg_not_logged'));
		}
		if ((int)$logged_info->member_srl !== $member_srl && (!self::settingAllowsInfo($member_srl) || !isset(self::menuActions($member_srl, self::mid())['info'])))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		// 회원 메뉴 주소를 고정한 Rhymix 는 그 mid 에서만 회원 정보를 그린다 (My::run 이 맞춰 준다)
		My::run('member', 'dispMemberInfo', array('member_srl' => $member_srl));
		$member = (array)\Context::get('memberInfo');
		if (empty($member['member_srl']) || (int)$member['member_srl'] !== $member_srl)
		{
			throw new ApiError(404, 'member_not_found', Auth::lang('msg_not_founded'));
		}
		// 웹 회원 정보 화면(엔진 기본·sketchbook5 스킨)과 같은 항목·조건:
		// ① 가입 양식 항목(displayDatas — 엔진이 공개 항목만, 관리자·본인은 전부) ② 회원 그룹·가입일 ③ 최근 로그인(본인·관리자만)
		// 이미지 항목(프로필 사진·이미지 이름·이미지 마크)은 image_url 로 (1.0.5~). 그림을 모르는 예전 앱은 value 의 안내 문구를 보인다(1.0.6~, 새 앱은 그림만)
		$fields = array();
		foreach ((array)\Context::get('displayDatas') as $item)
		{
			$name = (string)($item->name ?? '');
			$title = strip_tags((string)($item->title ?? $name));
			$value = $item->value ?? '';
			$value = is_array($value) ? implode(', ', $value) : (string)$value;
			if (in_array($name, array('profile_image', 'image_name', 'image_mark'), true))
			{
				if (preg_match('/<img[^>]+src="([^"]+)"/i', $value, $m))
				{
					$fields[] = array('name' => $name, 'title' => $title, 'value' => \appapiText::t('(앱을 업데이트하면 그림을 볼 수 있습니다)'), 'image_url' => Core::absoluteUrl(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8')));
				}
				continue;
			}
			$text = trim(html_entity_decode(strip_tags(str_replace(array('<br>', '<br />', '<br/>'), "\n", $value)), ENT_QUOTES, 'UTF-8'));
			if ($text === '')
			{
				continue;
			}
			$fields[] = array('name' => $name, 'title' => $title, 'value' => $text);
		}
		$groups = array_filter(array_map('strval', (array)($member['group_list'] ?? array())));
		if ($groups)
		{
			$fields[] = array('name' => 'group_list', 'title' => Auth::lang('member_group'), 'value' => implode(', ', $groups));
		}
		if (!empty($member['regdate']))
		{
			$fields[] = array('name' => 'regdate', 'title' => Auth::lang('signup_date'), 'value' => zdate($member['regdate'], 'Y-m-d'));
		}
		$self_or_admin = $logged_info && ((int)$logged_info->member_srl === $member_srl || $logged_info->is_admin === 'Y');
		if ($self_or_admin && !empty($member['last_login']))
		{
			$fields[] = array('name' => 'last_login', 'title' => Auth::lang('last_login'), 'value' => zdate($member['last_login'], 'Y-m-d'));
		}
		$image = getModel('member')->getProfileImage($member_srl);
		// 이름: 어느 게시판에서 눌렀는지(mid, 모듈 1.0.3~ 선택) 알면 그 게시판의 이름 표시 설정, 모르면 사이트 기본값
		$mid = self::mid();
		$board = $mid !== '' ? getModel('module')->getModuleInfoByMid($mid) : null;
		$module_srl = ($board && $board->module === 'board') ? (int)$board->module_srl : 0;
		return array(
			'member_srl' => $member_srl,
			'nick_name' => Core::displayName(html_entity_decode((string)($member['nick_name'] ?? ''), ENT_QUOTES, 'UTF-8'), $member_srl, $module_srl),
			'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			'regdate' => isset($member['regdate']) ? Core::isoTime($member['regdate']) : null,
			'fields' => $fields,
		);
	}

	/** 쪽지 보내기: 엔진의 쪽지 보내기 (받는 사람 설정·권한·포인트는 엔진이) */
	public static function sendMessage()
	{
		$receiver = Core::intParam('receiver_srl');
		$title = trim(Core::str('title'));
		$content = trim(str_replace(array("\r\n", "\r"), "\n", Core::str('content')));
		if (!$receiver || $title === '' || $content === '')
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('제목과 내용을 입력해 주세요.'));
		}
		self::runAction('procCommunicationSendMessage', array(
			'receiver_srl' => $receiver,
			'title' => mb_substr($title, 0, 200),
			'content' => nl2br(htmlspecialchars(mb_substr($content, 0, 10000), ENT_QUOTES, 'UTF-8')),
		));
		return array('sent' => true);
	}

	/** 친구 등록: 엔진의 친구 추가 (기본 친구 그룹) */
	public static function addFriend()
	{
		$target = Core::intParam('target_srl');
		if (!$target)
		{
			throw new ApiError(400, 'missing_member_srl', 'target_srl is required');
		}
		self::runAction('procCommunicationAddFriend', array('target_srl' => $target));
		return array('added' => true);
	}

	private static function runAction($act, array $vars)
	{
		try
		{
			Board::run('', $act, array('module' => 'communication', 'window_type' => 'self') + $vars, false, true);
		}
		catch (ApiError $e)
		{
			// 쪽지를 받지 않는 회원, 이미 친구 등 엔진이 거절한 이유를 그대로 보여 준다
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
	}

	private static function mid()
	{
		$mid = Core::str('mid', '');
		return preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid) ? $mid : '';
	}
}
